import * as L from './logic.js';

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fold = (s) => String(s ?? '').replace(/đ/g, 'dj').replace(/Đ/g, 'dj').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const LS = {
  get(k, d) { try { const v = localStorage.getItem('cz:' + k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem('cz:' + k, JSON.stringify(v)); } catch { /* privatni način rada */ } },
};
const dtf = new Intl.DateTimeFormat('hr-HR', { day: 'numeric', month: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
const df = new Intl.DateTimeFormat('hr-HR', { day: 'numeric', month: 'numeric', year: 'numeric' });
const fmtDT = (s) => (s ? dtf.format(new Date(s)) : '–');
const fmtD = (s) => (s ? df.format(new Date(s + (s.length === 10 ? 'T12:00:00' : ''))) : '–');

const S = {
  meta: null, groups: [], groupsById: {}, defaults: [], prods: {}, shards: new Set(), search: null,
  items: [], settings: LS.get('settings', { allowSubst: true, excludeStale: false, minSaving: 2, start: 'center', consumption: '', fuel: '', gps: null }),
};

// ------------------------------------------------------------------ podaci

async function getJSON(path) {
  const r = await fetch(path, { cache: 'no-cache' });
  if (!r.ok) throw new Error(`${path}: HTTP ${r.status}`);
  return r.json();
}

async function loadShard(n) {
  if (S.shards.has(n)) return;
  const d = await getJSON(`data/p/${n}.json`);
  Object.assign(S.prods, d);
  S.shards.add(n);
}

function shardFor(key) {
  for (const g of S.groups) for (const [k, sh] of g.members) if (k === key) return sh;
  const row = S.search?.find((r) => r[0] === key);
  return row ? row[5] : null;
}

async function ensureProducts(keys) {
  const need = new Set();
  for (const k of keys) {
    if (!k || S.prods[k]) continue;
    const it = S.items.find((i) => i.pick === k);
    const sh = it?.shard ?? shardFor(k);
    if (sh != null) need.add(sh);
  }
  await Promise.all([...need].map(loadShard));
}

const stores = () => S.meta.stores;
function startPoint() {
  if (S.settings.start === 'gps' && S.settings.gps) return S.settings.gps;
  return { lat: S.meta.center.lat, lon: S.meta.center.lon };
}
const dist = (st) => L.haversineKm(startPoint(), st);
const opts = () => ({ excludeStale: S.settings.excludeStale, allowSubst: S.settings.allowSubst });

function saveItems() { LS.set('items', S.items); }
function saveSettings() { LS.set('settings', S.settings); }

// ------------------------------------------------------------------ pokretanje

async function init() {
  try {
    const [meta, groups, gp] = await Promise.all([getJSON('data/meta.json'), getJSON('data/groups.json'), getJSON('data/gp.json')]);
    S.meta = meta;
    S.groups = groups.groups;
    S.defaults = groups.defaults;
    S.groupsById = Object.fromEntries(S.groups.map((g) => [g.id, g]));
    Object.assign(S.prods, gp);
  } catch (e) {
    $('#fresh').textContent = 'Podaci nisu dostupni';
    $('#list').innerHTML = `<div class="card"><h3>Podaci još nisu objavljeni</h3>
      <p class="small">Aplikacija prikazuje samo stvarne cijene iz službenih cjenika. Dnevni uvoz još nije stvorio podatke
      (ili ih ovaj uređaj ne može dohvatiti). Pokrenite uvoz prema uputama u README datoteci.</p>
      <p class="small muted">${esc(e.message)}</p></div>`;
    return;
  }
  S.items = LS.get('items', null) || S.defaults.map((d) => ({ id: d.id, name: d.name, family: d.id, group: d.group, pick: null, qty: d.qty, fav: false, inBasket: false }));
  await ensureProducts(S.items.map((i) => i.pick));
  renderHeader();
  renderList();
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
}

function renderHeader() {
  const m = S.meta;
  const cov = Object.values(m.coverage);
  const okChains = cov.filter((c) => c.status === 'pokriveno' || c.status === 'djelomično').length;
  $('#fresh').textContent = `Podaci: ${fmtDT(m.generated_at)} · ${m.stores.length} poslovnica · ${okChains}/${cov.length} lanaca – pokrivenost ›`;
  const ageH = (Date.now() - new Date(m.generated_at).getTime()) / 36e5;
  const staleStores = m.stores.filter((s) => s.stale || s.old_file).length;
  const msgs = [];
  if (ageH > 26) msgs.push(`Podaci nisu ažurirani od ${fmtDT(m.generated_at)} – cijene mogu biti zastarjele.`);
  if (staleStores) msgs.push(`${staleStores} poslovnica koristi posljednje valjane, ali starije podatke (označeno kod ponude).`);
  const b = $('#banner');
  b.hidden = !msgs.length;
  b.textContent = msgs.join(' ');
}

// ------------------------------------------------------------------ prikaz ponuda

function availChip(o) {
  if (o.avail === 0) return '<span class="chip bad">NEMA NA ZALIHI — prema dostupnim podacima.</span>';
  if (o.avail === 1) return `<span class="chip ok">Dostupno prema podacima${o.stock != null ? ` · zaliha ${L.fmtNum(o.stock, 0)} (može se promijeniti)` : ''}</span>`;
  return '<span class="chip unk">DOSTUPNOST NIJE POZNATA</span>';
}

function sourceChip(st) {
  if (!st.source_url || !/^https?:/i.test(st.source_url)) return '';
  const zip = /\.zip(\?|$)/i.test(st.source_url);
  const label = zip ? `izvor: ZIP trgovca → ${esc((st.source_file || '').split('/').pop())}` : 'izvorni cjenik trgovca ↗';
  return `<a class="chip src" href="${esc(st.source_url)}" target="_blank" rel="noopener">${label}</a>`;
}

function freshChip(st) {
  if (st.stale) return `<span class="chip stale">⚠ potencijalno zastarjelo · zadnje valjano ${fmtDT(st.last_ok_at)}</span>`;
  if (st.old_file) return `<span class="chip stale">⚠ cjenik od ${fmtD(st.file_date)} – potencijalno zastarjelo</span>`;
  return `<span class="chip">cjenik ${fmtD(st.file_date)} · preuzeto ${fmtDT(st.fetched_at)}</span>`;
}

function storeLine(st) {
  return `${esc(st.address)}${st.city ? ', ' + esc(st.city) : ''} · ${L.fmtNum(dist(st), 1)} km`;
}

function offerRow(r, i, mode, showName) {
  const st = r.store;
  const more = r.others?.length ? ` · <span class="muted">+${r.others.length} posl. iste cijene</span>` : '';
  const diff = i > 0 && r.diff > 0 ? `<span class="chip">+${L.eur(mode === 'opis' ? r.diff : r.diff)}${mode === 'opis' ? '/' + (r.up?.base || '') : ''} (+${L.pct(r.diffPct)})</span>` : '';
  const save = i === 0 && r.maxSaving > 0.004 ? `<span class="chip best">Najniža cijena · ušteda do ${L.eur(r.maxSaving)} (${L.pct(r.maxSavingPct)})</span>` : (i === 0 ? '<span class="chip best">Najniža cijena</span>' : '');
  const sale = r.special != null ? `<span class="chip sale">AKCIJA</span>` : '';
  const up = r.up ? `${L.unitTxt(r.up)}${r.up.small ? ` · ${L.eur(r.up.small.value)}/${r.up.small.label}` : ''}` : 'jed. cijena: količina nepoznata';
  const pname = showName ? `<div class="pname">${esc(r.prod.b ? r.prod.b + ' · ' : '')}${esc(r.prod.n)} · ${esc(L.packLabel(r.prod))}</div>` : '';
  return `<li class="offer ${i === 0 ? 'best' : ''}">
    <div class="rank">${i + 1}.</div>
    <div class="where"><div class="chain">${esc(st.chain_name)}${st.format ? ` <span class="muted small">${esc(st.format)}</span>` : ''}</div>
      <div class="addr">${storeLine(st)}${more}</div>${pname}</div>
    <div class="price"><b>${L.eur(r.eff)}</b>${r.special != null ? `<s>${L.eur(r.price)}</s>` : ''}<div class="up">${up}</div></div>
    <div class="meta">${save}${sale}${diff}${r.valueBest ? '<span class="chip value">Najisplativije pakiranje</span>' : ''}${availChip(r)}${freshChip(st)}${sourceChip(st)}${r.warn ? `<span class="chip unk">provjeri jed. cijenu: ${esc(r.warn)}</span>` : ''}</div>
  </li>`;
}

function analyse(item) {
  const g = S.groupsById[item.group];
  const t = L.topOffers(item, g, S.prods, stores(), dist, opts());
  const ref = t.refKey ? S.prods[t.refKey] : null;
  const best = t.rows[0];
  const alts = best && g && t.mode !== 'opis' ? L.alternatives(item, g, S.groupsById, S.prods, stores(), dist, best, opts()) : [];
  const bv = g ? L.bestValuePack(g, S.prods, stores(), dist) : null;
  if (best && bv && best.up && bv.up && bv.up.base === best.up.base && bv.up.value >= best.up.value - 1e-9) best.valueBest = true;
  return { g, t, ref, best, alts, bv };
}

function modeNote(t, ref) {
  if (t.mode === 'opis') return '<div class="note warn">Usporedba prema opisu – ovi artikli nemaju EAN (rasuto, vagano, pekara). Vrsta i kvaliteta mogu se razlikovati; poredano po cijeni po jedinici.</div>';
  if (t.mode === 'bez-ean') return '<div class="note warn">Artikl nema EAN – identitet nije potvrđen, uspoređuje se samo ista šifra unutar lanca. Usporedba je nesigurna.</div>';
  return '';
}

function card(item) {
  const { g, t, ref, best, alts, bv } = analyse(item);
  const sub = ref
    ? `${esc(ref.b ? ref.b + ' · ' : '')}${esc(ref.n)} · ${esc(L.packLabel(ref))}${ref.e ? ` · EAN ${esc(ref.e)}` : ''}${item.pick ? '' : ' <span class="muted">(automatski odabran)</span>'}`
    : esc(g ? g.label : 'Nije odabran artikl');
  let body = '';
  if (!t.rows.length) {
    body = `<div class="empty">Nema potvrđene cijene u pokrivenim trgovinama${S.settings.excludeStale ? ' (zastarjeli podaci isključeni)' : ''}.</div>`;
  } else {
    body = `<ul class="offers">${t.rows.map((r, i) => offerRow(r, i, t.mode, t.mode === 'opis')).join('')}</ul>`;
  }
  if (t.unavailCheaper?.length) {
    const u = t.unavailCheaper[0];
    body += `<div class="note bad">Jeftinije u ${esc(u.store.chain_name)} (${L.eur(u.eff)}), ali NEMA NA ZALIHI — prema dostupnim podacima.</div>`;
  }
  if (best && bv && !best.valueBest && bv.up && best.up && bv.up.base === best.up.base && bv.up.value < best.up.value - 1e-9) {
    body += `<div class="value-box"><b>Najisplativije pakiranje:</b> ${L.unitTxt(bv.up)} – ${esc(bv.prod.b ? bv.prod.b + ' ' : '')}${esc(bv.prod.n)} (${esc(L.packLabel(bv.prod))}), ${esc(bv.store.chain_name)}, ${L.eur(bv.eff)} za pakiranje.</div>`;
  }
  if (alts.length) {
    const a = alts[0];
    body += `<div class="alt"><b>Pametna alternativa — uštedi više:</b> ${esc(a.prod.b ? a.prod.b + ' · ' : '')}${esc(a.prod.n)} (${esc(L.packLabel(a.prod))})
      – ${L.eur(a.best.eff)} u ${esc(a.best.store.chain_name)} · ${L.unitTxt(a.up)} · ušteda ${L.eur(a.saving)} (${L.pct(a.savingPct)}) na usporedivoj količini
      <div class="why">${esc(a.reason)}${alts.length > 1 ? ` · još ${alts.length - 1} u detaljima` : ''}</div></div>`;
  }
  if (t.rows.length) body += modeNote(t, ref);
  return `<article class="card" data-id="${esc(item.id)}">
    <div class="card-head">
      <button class="star ${item.fav ? '' : 'off'}" data-act="fav" aria-label="Omiljeno">★</button>
      <div class="card-title" data-act="open"><h3>${esc(item.name)}</h3><div class="sub">${g && ref ? esc(g.label) + ' · ' : ''}${sub}</div></div>
      <button class="add-basket ${item.inBasket ? 'on' : ''}" data-act="basket">${item.inBasket ? '✓ U košarici' : '+ Košarica'}</button>
    </div>
    <div data-act="open">${body}</div>
  </article>`;
}

function renderList() {
  const items = S.items.slice().sort((a, b) => (b.fav - a.fav));
  $('#list').innerHTML = items.map(card).join('') +
    '<button class="btn ghost" id="btn-add2" style="margin:6px auto 0">＋ Dodaj proizvod</button>';
  $('#basket-count').textContent = S.items.filter((i) => i.inBasket).length;
  $('#btn-add2').onclick = () => openSearch(null);
}

$('#list').addEventListener('click', (e) => {
  if (e.target.closest('a')) return;   // poveznica na izvorni cjenik
  const el = e.target.closest('[data-act]');
  const cardEl = e.target.closest('.card');
  if (!el || !cardEl) return;
  const item = S.items.find((i) => i.id === cardEl.dataset.id);
  if (!item) return;
  if (el.dataset.act === 'fav') { item.fav = !item.fav; saveItems(); renderList(); }
  else if (el.dataset.act === 'basket') { item.inBasket = !item.inBasket; saveItems(); renderList(); }
  else if (el.dataset.act === 'open') openItem(item);
});

// ------------------------------------------------------------------ list (sheet)

function openSheet(title, html) {
  $('#sheet-title').textContent = title;
  $('#sheet-body').innerHTML = html;
  $('#sheet').hidden = false;
  $('#sheet-body').scrollTop = 0;
  document.body.style.overflow = 'hidden';
}
function closeSheet() { $('#sheet').hidden = true; document.body.style.overflow = ''; renderList(); }
$('#sheet-close').onclick = closeSheet;

function qtyUnit(item) {
  const g = S.groupsById[item.group];
  if (!item.pick && g && g.compare === 'opis') return g.base[0] === 'kg' ? 'kg' : g.base[0];
  return 'kom';
}
const qtyStep = (item) => (qtyUnit(item) === 'kg' || qtyUnit(item) === 'l' ? 0.5 : 1);

function familyGroups(item) {
  const fam = S.groups.filter((g) => g.item === item.family);
  if (fam.length) return fam;
  const p = item.pick && S.prods[item.pick];
  return p ? p.g.map((id) => S.groupsById[id]).filter(Boolean) : [];
}

function openItem(item) {
  const { g, t, ref, alts, bv } = analyse(item);
  const fam = familyGroups(item);
  const variant = fam.length ? `<label class="small muted">Vrsta / varijanta (uspoređuju se samo usporedivi artikli)</label>
     <select id="sel-group">${fam.map((x) => `<option value="${esc(x.id)}" ${x.id === item.group ? 'selected' : ''}>${esc(x.label)} (${x.members.length})</option>`).join('')}
     ${g ? '' : '<option selected value="">– bez skupine –</option>'}</select>` : '<div class="small muted">Artikl ne pripada nijednoj skupini usporedivih proizvoda – pametne alternative nisu dostupne.</div>';

  let picker = '';
  if (g) {
    const mem = g.members.map(([k]) => S.prods[k]).filter(Boolean).length ? g.members.map(([k]) => [k, S.prods[k]]).filter(([, p]) => p) : [];
    const rows = mem.map(([k, p]) => {
      const offs = L.storeOffers(p, stores());
      const min = Math.min(...offs.map((o) => o.eff));
      return { k, p, n: offs.length, min, up: L.unitPrice(min, p, g.base[0], g.kom_kao_pranje) };
    }).sort((a, b) => b.n - a.n || a.min - b.min).slice(0, 80);
    picker = `<ul class="pick-list" id="pick-list">
      ${g.compare === 'ean' ? `<li data-k="" class="${item.pick ? '' : 'sel'}"><div class="pn"><b>Automatski</b><div class="pm">najrasprostranjeniji artikl s EAN-om u skupini</div></div></li>` : `<li data-k="" class="${item.pick ? '' : 'sel'}"><div class="pn"><b>Najjeftiniji u skupini</b><div class="pm">usporedba prema opisu (bez EAN-a)</div></div></li>`}
      ${rows.map((r) => `<li data-k="${esc(r.k)}" class="${item.pick === r.k ? 'sel' : ''}"><div class="pn">${esc(r.p.b ? r.p.b + ' · ' : '')}${esc(r.p.n)}
        <div class="pm">${esc(L.packLabel(r.p))}${r.p.e ? ' · EAN ' + esc(r.p.e) : ' · bez EAN-a'} · ${r.n} posl.</div></div>
        <div class="n small">od ${L.eur(r.min)}<div class="pm">${r.up ? L.unitTxt(r.up) : ''}</div></div></li>`).join('')}
    </ul>${g.members.length > 80 ? `<div class="small muted">Prikazano 80 od ${g.members.length}. Za ostale koristite pretragu.</div>` : ''}`;
  }

  const all = L.collapse(t.all, dist).sort((a, b) => (t.mode === 'opis' ? a.up.value - b.up.value : a.eff - b.eff));
  const allHtml = all.length ? `<ul class="offers">${all.map((r, i) => offerRow({ ...r, diff: 0 }, i, t.mode, t.mode === 'opis').replace('class="offer best"', i === 0 ? 'class="offer best"' : 'class="offer"')
      + (r.others.length ? `<details style="margin:-2px 0 4px 30px"><summary>Sve poslovnice (${r.others.length + 1})</summary><div class="small">${[r, ...r.others].map((o) => `${esc(o.store.chain_name)} – ${storeLine(o.store)}`).join('<br>')}</div></details>` : '')).join('')}</ul>` : '<div class="empty">Nema ponuda.</div>';

  const altHtml = alts.length ? alts.map((a) => `<div class="alt"><b>${esc(a.prod.b ? a.prod.b + ' · ' : '')}${esc(a.prod.n)}</b> (${esc(L.packLabel(a.prod))})<br>
      ${esc(a.best.store.chain_name)} – ${storeLine(a.best.store)}<br>
      Cijena ${L.eur(a.best.eff)}${a.best.special != null ? ' (akcija)' : ''} · ${L.unitTxt(a.up)} · uspoređeno s: ${esc(ref ? (ref.b ? ref.b + ' ' : '') + ref.n : '')}<br>
      Ušteda ${L.eur(a.saving)} (${L.pct(a.savingPct)}) na usporedivoj količini · ${availChip(a.best)}
      <div class="why">${esc(a.reason)}</div>
      <button class="btn ghost small" data-use="${esc(a.prodKey)}" style="margin-top:6px">Koristi ovaj artikl</button></div>`).join('')
    : `<div class="empty">${t.mode === 'opis' ? 'Za usporedbu prema opisu prikazuje se najjeftiniji usporedivi artikl po poslovnici (gore).' : 'Nema jeftinije usporedive alternative prema dostupnim podacima.'}</div>`;

  const unit = qtyUnit(item);
  openSheet(item.name, `
    <div class="sec"><h4>Što uspoređujem</h4>${variant}
      ${ref ? `<div class="small" style="margin-top:8px"><b>Referentni artikl:</b> ${esc(ref.b ? ref.b + ' · ' : '')}${esc(ref.n)} · ${esc(L.packLabel(ref))}${ref.e ? ' · EAN ' + esc(ref.e) : ' · bez EAN-a'}${ref.cat ? ' · ' + esc(ref.cat) : ''}</div>` : ''}
      ${modeNote(t, ref)}
      ${picker ? `<details ${item.pick ? '' : ''}><summary>Odaberi marku / točan artikl</summary>${picker}</details>` : ''}
      <button class="btn ghost" id="btn-replace" style="margin-top:8px">Zamijeni artikl (pretraga)</button>
    </div>
    <div class="sec"><h4>Košarica</h4>
      <div class="row"><span>Količina (${unit === 'kom' ? 'pakiranja' : unit})</span>
        <span class="stepper"><button id="q-minus">−</button><span id="q-val">${L.fmtNum(item.qty, 2)} ${unit}</span><button id="q-plus">＋</button></span></div>
      <button class="btn" id="btn-bk">${item.inBasket ? '✓ U današnjoj košarici (ukloni)' : 'Dodaj u današnju košaricu'}</button>
    </div>
    <div class="sec"><h4>Sve ponude (${t.all.length} poslovnica)</h4>${allHtml}
      ${t.all.some((x) => x.low30) ? '<div class="small muted">Najniža cijena u posljednjih 30 dana navedena je u cjeniku trgovca.</div>' : ''}</div>
    ${bv ? `<div class="sec"><h4>Najisplativije pakiranje u skupini</h4><div class="small">${L.unitTxt(bv.up)} – ${esc(bv.prod.b ? bv.prod.b + ' ' : '')}${esc(bv.prod.n)} (${esc(L.packLabel(bv.prod))}), ${esc(bv.store.chain_name)} – ${storeLine(bv.store)}, ${L.eur(bv.eff)} za pakiranje.<br><span class="muted">Najniža cijena = najmanji iznos za cijelo pakiranje; najisplativije = najniža cijena po jedinici.</span></div></div>` : ''}
    <div class="sec"><h4>Pametna alternativa — uštedi više</h4>${altHtml}</div>
    <div class="sec">
      <div class="row"><button class="btn ghost" id="btn-fav">${item.fav ? '★ Ukloni iz omiljenih' : '☆ Označi kao omiljeno'}</button>
      <button class="btn danger" id="btn-del">Ukloni s popisa</button></div>
    </div>`);

  const rerender = () => { saveItems(); openItem(item); };
  $('#sel-group')?.addEventListener('change', (e) => { item.group = e.target.value || null; item.pick = null; rerender(); });
  $('#pick-list')?.addEventListener('click', (e) => { const li = e.target.closest('li'); if (!li) return; item.pick = li.dataset.k || null; rerender(); });
  $('#btn-replace').onclick = () => openSearch(item);
  $('#q-minus').onclick = () => { item.qty = Math.max(qtyStep(item), +(item.qty - qtyStep(item)).toFixed(2)); rerender(); };
  $('#q-plus').onclick = () => { item.qty = +(item.qty + qtyStep(item)).toFixed(2); rerender(); };
  $('#btn-bk').onclick = () => { item.inBasket = !item.inBasket; rerender(); };
  $('#btn-fav').onclick = () => { item.fav = !item.fav; rerender(); };
  $('#btn-del').onclick = () => { if (confirm(`Ukloniti „${item.name}” s popisa?`)) { S.items = S.items.filter((i) => i !== item); saveItems(); closeSheet(); } };
  $('#sheet-body').querySelectorAll('[data-use]').forEach((b) => b.onclick = () => { item.pick = b.dataset.use; rerender(); });
}

// ------------------------------------------------------------------ pretraga i dodavanje

async function openSearch(replaceItem) {
  openSheet(replaceItem ? `Zamijeni: ${replaceItem.name}` : 'Dodaj proizvod', `
    <div class="sec"><input type="search" id="q" placeholder="npr. mlijeko dukat, kava barcaffe, EAN…" autocomplete="off">
      <div class="small muted" style="margin-top:6px" id="q-info">Učitavanje popisa artikala…</div></div>
    <div class="sec"><ul class="pick-list" id="q-res"></ul></div>`);
  try {
    if (!S.search) S.search = (await getJSON('data/search.json')).map((r) => [...r, fold(`${r[1]} ${r[2]} ${r[0].startsWith('e:') ? r[0].slice(2) : ''}`)]);
  } catch (e) { $('#q-info').textContent = 'Popis artikala nije dostupan: ' + e.message; return; }
  $('#q-info').textContent = `${S.search.length.toLocaleString('hr-HR')} artikala u pokrivenim poslovnicama.`;
  const run = () => {
    const toks = fold($('#q').value).split(/\s+/).filter(Boolean);
    if (!toks.length) { $('#q-res').innerHTML = ''; return; }
    const res = [];
    for (const r of S.search) {
      if (toks.every((t) => r[8].includes(t))) { res.push(r); if (res.length >= 60) break; }
    }
    $('#q-res').innerHTML = res.map((r) => `<li data-k="${esc(r[0])}" data-sh="${r[5]}"><div class="pn">${esc(r[2] ? r[2] + ' · ' : '')}${esc(r[1])}
      <div class="pm">${r[4] != null ? L.fmtNum(r[4], 3) + ' ' + esc(r[3]) : 'količina nepoznata'} · ${r[0].startsWith('e:') ? 'EAN ' + esc(r[0].slice(2)) : 'bez EAN-a'} · ${r[6]} posl.</div></div>
      <div class="n small">od ${L.eur(r[7])}</div></li>`).join('') || '<li class="muted">Nema rezultata.</li>';
  };
  $('#q').addEventListener('input', run);
  $('#q').focus();
  $('#q-res').addEventListener('click', async (e) => {
    const li = e.target.closest('li[data-k]');
    if (!li) return;
    const k = li.dataset.k;
    await loadShard(+li.dataset.sh);
    const p = S.prods[k];
    if (!p) return;
    if (replaceItem) {
      replaceItem.pick = k;
      replaceItem.shard = +li.dataset.sh;
      if (!p.g.includes(replaceItem.group)) replaceItem.group = p.g[0] || null;
      saveItems();
      openItem(replaceItem);
    } else {
      const name = (p.n.length > 40 ? p.n.slice(0, 40) + '…' : p.n);
      const it = { id: 'u' + Date.now(), name, family: null, group: p.g[0] || null, pick: k, shard: +li.dataset.sh, qty: 1, fav: true, inBasket: false };
      S.items.unshift(it);
      saveItems();
      openItem(it);
    }
  });
}
$('#btn-add').onclick = () => openSearch(null);

// ------------------------------------------------------------------ košarica i optimizacija

async function roadMatrix(points) {
  // OSRM (OpenStreetMap) – besplatna javna usluga cestovnih udaljenosti, bez ključa
  const coords = points.map((p) => `${p.lon.toFixed(5)},${p.lat.toFixed(5)}`).join(';');
  const r = await fetch(`https://router.project-osrm.org/table/v1/driving/${coords}?annotations=distance`);
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const d = await r.json();
  if (d.code !== 'Ok') throw new Error(d.code);
  return d.distances;
}

function linesTable(lines) {
  return `<table class="t">${lines.map((l) => {
    const p = S.prods[l.prodKey];
    return `<tr><td>${esc(l.item.name)}${l.subst ? ' <span class="chip value">zamjena</span>' : ''}${l.approx ? ' <span class="chip unk">≈ po jed. cijeni</span>' : ''}
      <div class="small muted">${p ? esc((p.b ? p.b + ' · ' : '') + p.n) : ''}${l.packs ? ` · ${L.fmtNum(l.packs, 2)} × ${L.eur(l.unit)}` : ` · ${L.fmtNum(l.item.qty, 2)} × ${L.eur(l.unit)}`}</div></td>
      ${l.store ? `<td class="small">${esc(l.store.chain_name)}</td>` : ''}<td class="n">${L.eur(l.cost)}</td></tr>`;
  }).join('')}</table>`;
}

function openBasket() {
  const basket = S.items.filter((i) => i.inBasket);
  const s = S.settings;
  openSheet('Optimiziraj moju kupnju', `
    <div class="sec"><h4>Današnja košarica (${basket.length})</h4>
      ${basket.length ? basket.map((it) => `<div class="row" data-id="${esc(it.id)}"><span>${esc(it.name)}<div class="small muted">${esc(S.groupsById[it.group]?.label || '')}</div></span>
        <span class="stepper"><button data-q="-">−</button><span>${L.fmtNum(it.qty, 2)} ${qtyUnit(it)}</span><button data-q="+">＋</button><button data-q="x" aria-label="Ukloni">✕</button></span></div>`).join('')
        : '<div class="empty">Košarica je prazna. Na početnom zaslonu dodirnite „+ Košarica” kod proizvoda.</div>'}
      ${basket.length ? '' : `<button class="btn ghost" id="bk-all">Dodaj sve s popisa</button>`}
    </div>
    <div class="sec"><h4>Postavke</h4>
      <label class="row"><span>Dopusti zamjenu usporedivim artiklom<div class="small muted">ako trgovina nema odabrani artikl (označeno „zamjena”)</div></span><input type="checkbox" id="o-subst" ${s.allowSubst ? 'checked' : ''}></label>
      <label class="row"><span>Isključi potencijalno zastarjele cjenike</span><input type="checkbox" id="o-stale" ${s.excludeStale ? 'checked' : ''}></label>
      <label class="row"><span>Dodatna trgovina se isplati od uštede (€)</span><input type="number" id="o-min" min="0" step="0.5" value="${s.minSaving}"></label>
      <h4 style="margin-top:10px">Trošak puta (neobavezno)</h4>
      <div class="seg" id="o-start"><button data-v="center" class="${s.start !== 'gps' ? 'on' : ''}">Središte Zaprešića</button><button data-v="gps" class="${s.start === 'gps' ? 'on' : ''}">Moja lokacija</button></div>
      <label class="row"><span>Potrošnja (l ili kWh / 100 km)</span><input type="number" id="o-cons" min="0" step="0.1" value="${esc(s.consumption)}" placeholder="npr. 6,5"></label>
      <label class="row"><span>Cijena goriva / energije (€ po l ili kWh)</span><input type="number" id="o-fuel" min="0" step="0.01" value="${esc(s.fuel)}" placeholder="npr. 1,45"></label>
      <div class="small muted">Cestovne udaljenosti računa besplatna usluga OSRM (OpenStreetMap). Ako nije dostupna, trošak puta se ne prikazuje.</div>
      <button class="btn" id="o-run" style="margin-top:10px;width:100%">Izračunaj</button>
    </div>
    <div id="bk-res"></div>`);

  const body = $('#sheet-body');
  body.querySelectorAll('[data-q]').forEach((b) => b.onclick = () => {
    const it = S.items.find((i) => i.id === b.closest('[data-id]').dataset.id);
    if (b.dataset.q === 'x') it.inBasket = false;
    else it.qty = Math.max(qtyStep(it), +(it.qty + (b.dataset.q === '+' ? 1 : -1) * qtyStep(it)).toFixed(2));
    saveItems(); readSettings(); openBasket();
  });
  $('#bk-all')?.addEventListener('click', () => { S.items.forEach((i) => (i.inBasket = true)); saveItems(); openBasket(); });
  $('#o-start').onclick = (e) => {
    const v = e.target.dataset.v; if (!v) return;
    if (v === 'gps') {
      navigator.geolocation?.getCurrentPosition((pos) => { S.settings.gps = { lat: pos.coords.latitude, lon: pos.coords.longitude }; S.settings.start = 'gps'; readSettings(); openBasket(); },
        () => alert('Lokacija nije dostupna – koristi se središte Zaprešića.'), { timeout: 10000 });
    } else { S.settings.start = 'center'; readSettings(); openBasket(); }
  };
  $('#o-run').onclick = () => { readSettings(); computeBasket(); };
  if (basket.length) computeBasket();
}

function readSettings() {
  const v = (id) => document.getElementById(id);
  if (!v('o-subst')) return;
  S.settings.allowSubst = v('o-subst').checked;
  S.settings.excludeStale = v('o-stale').checked;
  S.settings.minSaving = parseFloat(String(v('o-min').value).replace(',', '.')) || 0;
  S.settings.consumption = v('o-cons').value;
  S.settings.fuel = v('o-fuel').value;
  saveSettings();
}

async function computeBasket() {
  const basket = S.items.filter((i) => i.inBasket);
  const out = $('#bk-res');
  if (!basket.length) { out.innerHTML = ''; return; }
  await ensureProducts(basket.map((i) => i.pick));
  const r = L.optimizeBasket(basket, S.groupsById, S.prods, stores(), dist, opts());
  let html = '';
  if (r.notAnywhere.length) html += `<div class="note bad">Bez potvrđene cijene ni u jednoj pokrivenoj trgovini: ${r.notAnywhere.map((i) => esc(i.name)).join(', ')}. Nisu uključeni u izračun.</div>`;

  // trošak puta
  const cons = parseFloat(String(S.settings.consumption).replace(',', '.'));
  const fuel = parseFloat(String(S.settings.fuel).replace(',', '.'));
  const travel = {};
  let travelNote = '';
  if (cons > 0 && fuel > 0) {
    const sets = [1, 2, 3, 'unlimited'].filter((k) => r.C[k]).map((k) => [k, r.C[k].sis]);
    const uniq = [...new Set(sets.flatMap(([, s]) => s))];
    if (uniq.length <= 24) {
      try {
        const pts = [startPoint(), ...uniq.map((si) => stores()[si])];
        const m = await roadMatrix(pts);
        for (const [k, sis] of sets) {
          const tour = L.bestTour(m, sis.map((si) => uniq.indexOf(si) + 1));
          if (tour) travel[k] = { km: tour.d / 1000, cost: (tour.d / 1000) * (cons / 100) * fuel };
        }
        travelNote = '<div class="small muted">Trošak puta: kružna vožnja od početne lokacije do trgovina i natrag, cestovne udaljenosti (OSRM). Procjena.</div>';
      } catch (e) {
        travelNote = `<div class="note warn">Trošak puta nije izračunat – usluga cestovnih udaljenosti nije dostupna (${esc(e.message)}).</div>`;
      }
    } else travelNote = '<div class="note warn">Previše trgovina za izračun puta.</div>';
  } else travelNote = '<div class="small muted">Trošak puta nije izračunat – unesite potrošnju i cijenu goriva.</div>';

  // preporuka
  const rec = L.recommend(r.C, travel, S.settings.minSaving);
  if (rec) {
    const o = rec.rec;
    const tv = o.travel;
    html += `<div class="sec scn rec"><h4>Preporuka</h4>
      <div class="total">${L.eur(o.total)}${tv ? ` <span class="small muted">+ put ≈ ${L.eur(tv.cost)} (${L.fmtNum(tv.km, 1)} km)</span>` : ''}</div>
      <div>${o.sis.length === 1 ? 'Sve u jednoj trgovini' : `${o.sis.length} trgovine`}: ${o.stores.map((st) => `<b>${esc(st.chain_name)}</b> – ${storeLine(st)}`).join('<br>')}</div>
      <div class="small muted" style="margin-top:6px">Dodatna trgovina preporučuje se samo ako štedi barem ${L.eur(S.settings.minSaving)}${Object.keys(travel).length ? ' nakon troška puta' : ''}.
      ${rec.opts.map((x) => `<br>${x.k === 'unlimited' ? 'Bez ograničenja' : 'Najviše ' + x.k}: ${L.eur(x.total)} proizvodi${x.travel ? ` + ${L.eur(x.travel.cost)} put = <b>${L.eur(x.total + x.travel.cost)}</b>` : ''} (${x.sis.length} trg.)`).join('')}</div>
      ${linesTable(o.lines)}</div>`;
  }

  // A
  const A = r.completeA;
  const partial = r.A.filter((a) => !a.complete).slice(0, 5);
  html += `<div class="sec scn"><h4>A · Sve u jednoj trgovini</h4>
    ${A.length ? `<div class="total">${L.eur(A[0].total)}</div><div><b>${esc(A[0].store.chain_name)}</b> – ${storeLine(A[0].store)}</div>
      ${A[1] ? `<div class="small" style="margin-top:4px">Sljedeća: ${esc(A[1].store.chain_name)} (${esc(A[1].store.address)}) ${L.eur(A[1].total)} · razlika +${L.eur(A[1].total - A[0].total)}</div>` : ''}
      <details><summary>Detalji i ostale trgovine</summary>${linesTable(A[0].lines)}
        <table class="t" style="margin-top:8px">${A.slice(0, 12).map((a) => `<tr><td>${esc(a.store.chain_name)}<div class="small muted">${storeLine(a.store)}</div></td><td class="n">${L.eur(a.total)}</td></tr>`).join('')}</table></details>`
      : '<div class="empty">Nijedna pokrivena trgovina nema sve artikle iz košarice.</div>'}
    ${partial.length ? `<details><summary>Trgovine bez svih artikala (${r.A.filter((a) => !a.complete).length})</summary><table class="t">${partial.map((a) => `<tr><td>${esc(a.store.chain_name)}<div class="small muted">${storeLine(a.store)}</div>
       ${a.missing.length ? `<div class="small">Bez potvrđene cijene: ${a.missing.map((i) => esc(i.name)).join(', ')}</div>` : ''}
       ${a.unavail.length ? `<div class="small" style="color:var(--bad-ink)">Nedostupno prema podacima: ${a.unavail.map((i) => esc(i.name)).join(', ')}</div>` : ''}</td>
       <td class="n">${L.eur(a.total)}<div class="small muted">bez nedostajućih</div></td></tr>`).join('')}</table></details>` : ''}
  </div>`;

  // B
  html += `<div class="sec scn"><h4>B · Svaki artikl gdje je najjeftiniji</h4>
    <div class="total">${L.eur(r.B.total)}</div>
    <div>${r.B.stores.length} trgovina${r.B.savingVsA != null ? ` · ušteda ${L.eur(r.B.savingVsA)} (${L.pct(r.B.savingVsA / A[0].total)}) u odnosu na A` : ''}${travel.unlimited ? ` · put ≈ ${L.eur(travel.unlimited.cost)}` : ''}</div>
    ${r.B.stores.map((g) => `<div style="margin-top:8px"><b>${esc(g.store.chain_name)}</b> – ${storeLine(g.store)} · ${L.eur(g.subtotal)}${linesTable(g.lines)}</div>`).join('')}
  </div>`;

  // C
  html += `<div class="sec scn"><h4>C · Optimalno uz manje obilazaka</h4>
    <table class="t"><tr><th>Najviše</th><th>Trgovine</th><th class="n">Proizvodi</th><th class="n">vs. najniža</th>${Object.keys(travel).length ? '<th class="n">+ put</th>' : ''}</tr>
    ${[1, 2, 3, 'unlimited'].map((k) => {
      const c = r.C[k];
      if (!c) return `<tr><td>${k}</td><td colspan="3" class="muted">nije moguće kupiti sve u ${k} trg.</td></tr>`;
      return `<tr><td>${k === 'unlimited' ? 'bez ogr.' : k}</td><td class="small">${c.stores.map((st) => esc(st.chain_name)).join(', ')}</td><td class="n">${L.eur(c.total)}</td>
        <td class="n">+${L.eur(c.total - r.B.total)}</td>${Object.keys(travel).length ? `<td class="n">${travel[k] ? L.eur(c.total + travel[k].cost) : '–'}</td>` : ''}</tr>`;
    }).join('')}</table>${travelNote}</div>`;

  html += '<div class="small muted">Cijene su iz službenih cjenika trgovaca. Artikli potvrđeno nedostupni nisu uračunati kao kupljivi. Akcijske cijene uračunate su ako su navedene u cjeniku.</div>';
  out.innerHTML = html;
}

$('#btn-optimize').onclick = openBasket;
$('#btn-basket-list').onclick = openBasket;

// ------------------------------------------------------------------ pokrivenost

function openCoverage() {
  const m = S.meta;
  const cov = Object.entries(m.coverage);
  openSheet('Pokrivenost i aktualnost podataka', `
    <div class="sec small">Generirano: <b>${fmtDT(m.generated_at)}</b> · središte: ${esc(m.center.name)} · radijus ${m.radius_km} km (zračna udaljenost po koordinatama).<br>
      ${m.counts.stores} poslovnica, ${m.counts.products.toLocaleString('hr-HR')} artikala (${m.counts.with_ean.toLocaleString('hr-HR')} s EAN-om).
      ${Object.entries(m.excluded || {}).map(([k, v]) => `<br>Isključeno – ${esc(k)}: ${v}`).join('')}</div>
    ${cov.map(([id, c]) => {
      const st = m.stores.filter((s) => s.chain === id).sort((a, b) => a.dist_km - b.dist_km);
      return `<div class="sec"><h4>${esc(c.name)} · <span class="status-${esc(c.status.split(' ')[0])}">${esc(c.status)}</span></h4>
        <div class="small">Poslovnica u radijusu: ${c.stores_in_radius} (aktualno ${c.stores_fresh}, starije ${c.stores_stale}) · datoteka: ${c.files}
        ${c.quality ? `<br>Artikala: ${c.quality.artikala.toLocaleString('hr-HR')} · EAN ${L.pct(c.quality.udio_EAN)} · količina ${L.pct(c.quality.udio_kolicina)} · podatak o dostupnosti ${L.pct(c.quality.udio_dostupnost)}` : ''}
        <br>Izvor: <a href="${esc(c.source)}" target="_blank" rel="noopener">${esc(c.source)}</a></div>
        ${c.notes.map((n) => `<div class="note">${esc(n)}</div>`).join('')}
        ${c.errors.length ? `<details><summary>Greške (${c.errors.length})</summary><div class="small">${c.errors.map(esc).join('<br>')}</div></details>` : ''}
        ${st.length ? `<details><summary>Poslovnice (${st.length})</summary><table class="t">${st.map((s) => `<tr><td>${esc(s.format)} ${esc(s.address)}, ${esc(s.postcode)} ${esc(s.city)}
          <div class="small muted">${L.fmtNum(s.dist_km, 1)} km${s.exception ? ' · iznimka: ' + esc(s.exception) : ''} · lokacija: ${esc(s.loc_precision)} · ${s.lat}, ${s.lon}</div>
          <div class="small">${s.stale ? '⚠ izvor danas nedostupan – posljednji valjani podaci od ' + fmtDT(s.last_ok_at) : 'cjenik ' + fmtD(s.file_date) + (s.old_file ? ' ⚠ stariji od današnjeg' : '')}</div></td></tr>`).join('')}</table></details>` : ''}
      </div>`;
    }).join('')}
    <div class="sec small"><h4>Kako čitati podatke</h4>
      • Cijene su isključivo iz javnih strojno čitljivih cjenika (Odluka o objavi cjenika). Ništa nije procijenjeno ni izmišljeno.<br>
      • Cijena u cjeniku ne potvrđuje da je artikl fizički na polici. „NEMA NA ZALIHI” prikazuje se samo kad cjenik to izričito navodi; inače „DOSTUPNOST NIJE POZNATA”.<br>
      • Isti artikl = isti EAN/GTIN. Artikli bez EAN-a uspoređuju se samo prema opisu i označeni su kao nesigurni.<br>
      • Ako izvor jedan dan nije dostupan, koriste se posljednji valjani podaci (najviše 30 dana) uz oznaku „potencijalno zastarjelo”.</div>`);
}
$('#fresh').onclick = () => S.meta && openCoverage();

init();
