// Logika usporedbe – čiste funkcije bez DOM-a (testirano u tests/logic.test.mjs).
//
// Proizvod (iz data/p/N.json):
//   { n, b, e, cat, g:[skupine], q:[base, amount, count, per_item, washes, loose, source],
//     o:[[cijena, akcijska, najniža30, dostupno(1/0/null), zaliha, navedenaJedCijena, upozorenje, [indeksi trgovina]]] }

export const Q = { base: 0, amount: 1, count: 2, per: 3, washes: 4, loose: 5, src: 6 };
export const O = { p: 0, s: 1, l30: 2, a: 3, st: 4, up: 5, w: 6, stores: 7 };

export const eff = (o) => (o[O.s] != null && o[O.s] < o[O.p] ? o[O.s] : o[O.p]);

// ------------------------------------------------------------------ jedinice

/** Količina proizvoda u zadanoj osnovnoj jedinici (ili prirodnoj jedinici proizvoda). */
export function amountIn(prod, base, komKaoPranje = false) {
  const q = prod.q;
  if (base === 'pranje') {
    if (q[Q.washes]) return q[Q.washes];
    if (komKaoPranje && q[Q.base] === 'kom' && q[Q.amount]) return q[Q.amount];
    return null;
  }
  if (!base || q[Q.base] === base) return q[Q.amount] ?? null;
  return null;
}

/** Jedinična cijena za prikaz. Vraća null ako količina nije pouzdano poznata. */
export function unitPrice(price, prod, base, komKaoPranje = false) {
  const b = base || prod.q[Q.base];
  const amt = amountIn(prod, b, komKaoPranje);
  if (!amt || !price) return null;
  const v = price / amt;
  const out = { base: b, value: v };
  if (b === 'kg') out.small = { label: '100 g', value: v / 10 };
  if (b === 'l') out.small = { label: '100 ml', value: v / 10 };
  return out;
}

export function packLabel(prod) {
  const [base, amount, count, per, washes, loose] = prod.q;
  if (loose) return base === 'kg' ? 'na težinu (cijena po kg)' : 'rinfuza';
  if (amount == null) return 'količina nepoznata';
  const fmtAmt = (b, a) =>
    b === 'kg' ? (a < 1 ? `${fmtNum(a * 1000, 0)} g` : `${fmtNum(a, 3)} kg`)
    : b === 'l' ? (a < 1 ? `${fmtNum(a * 1000, 0)} ml` : `${fmtNum(a, 3)} l`)
    : `${fmtNum(a, 0)} kom`;
  let s = count && per && base !== 'kom' ? `${count} × ${fmtAmt(base, per)} (${fmtAmt(base, amount)})` : fmtAmt(base, amount);
  if (washes) s += ` · ${washes} pranja`;
  return s;
}

// ------------------------------------------------------------------ formatiranje (hr-HR)

const nf = {};
export function fmtNum(v, d = 2) {
  const k = d;
  nf[k] ||= new Intl.NumberFormat('hr-HR', { minimumFractionDigits: 0, maximumFractionDigits: d });
  return nf[k].format(v);
}
const eurF = new Intl.NumberFormat('hr-HR', { style: 'currency', currency: 'EUR', minimumFractionDigits: 2, maximumFractionDigits: 2 });
export const eur = (v) => (v == null ? '–' : eurF.format(v));
export const pct = (v) => `${new Intl.NumberFormat('hr-HR', { maximumFractionDigits: 0 }).format(v * 100)} %`;
export const unitTxt = (u) => (u ? `${eur(u.value)}/${u.base === 'pranje' ? 'pranje' : u.base}` : 'jed. cijena nepoznata');

// ------------------------------------------------------------------ ponude

/** Proširi ponude proizvoda na razinu prodavaonice. */
export function storeOffers(prod, stores) {
  const out = [];
  for (const o of prod.o) {
    for (const si of o[O.stores]) {
      const st = stores[si];
      if (!st) continue;
      out.push({ si, store: st, price: o[O.p], special: o[O.s] != null && o[O.s] < o[O.p] ? o[O.s] : null,
        eff: eff(o), low30: o[O.l30], avail: o[O.a], stock: o[O.st], statedUp: o[O.up], warn: o[O.w],
        stale: !!(st.stale || st.old_file) });
    }
  }
  return out;
}

/** Grupira ponude istog lanca s istom cijenom i dostupnošću (prikaz), najbliža poslovnica prva. */
export function collapse(offers, distFn) {
  const m = new Map();
  for (const x of offers) {
    const k = `${x.store.chain}|${x.eff}|${x.price}|${x.avail}|${x.prodKey || ''}`;
    if (!m.has(k)) m.set(k, { ...x, others: [] });
    else m.get(k).others.push(x);
  }
  const rows = [...m.values()];
  for (const r of rows) {
    const all = [r, ...r.others].sort((a, b) => distFn(a.store) - distFn(b.store));
    Object.assign(r, all[0], { others: all.slice(1) });
  }
  return rows;
}

/** Referentni artikl stavke: odabrani artikl ili automatski najrasprostranjeniji EAN artikl skupine. */
export function referentKey(item, group, prods) {
  if (item.pick) return item.pick;
  if (!group || group.compare !== 'ean') return null;
  let best = null;
  for (const [k] of group.members) {
    const p = prods[k];
    if (!p || !p.e) continue;
    const n = p.o.reduce((a, o) => a + o[O.stores].length, 0);
    const prices = p.o.map(eff).sort((a, b) => a - b);
    const med = prices[Math.floor(prices.length / 2)];
    if (!best || n > best.n || (n === best.n && med < best.med)) best = { k, n, med };
  }
  return best ? best.k : null;
}

/**
 * Najviše tri najpovoljnije ponude.
 * - EAN način: isti artikl u različitim poslovnicama, poredano po stvarnoj cijeni koju kupac plaća.
 * - 'opis' način (artikli bez EAN-a): najjeftiniji član skupine po poslovnici, po cijeni po jedinici – nesigurno.
 * Ponude potvrđeno NEDOSTUPNE ne ulaze u top 3; ako je takva jeftinija, vraća se u `unavailCheaper`.
 */
export function topOffers(item, group, prods, stores, distFn, opts = {}) {
  const refKey = referentKey(item, group, prods);
  let offers = [];
  let mode = 'ean';
  if (refKey) {
    const p = prods[refKey];
    if (!p) return { mode, refKey, rows: [], all: [] };
    offers = storeOffers(p, stores).map((x) => ({ ...x, prodKey: refKey, prod: p, up: unitPrice(x.eff, p) }));
    if (!p.e) mode = 'bez-ean';
  } else if (group && group.compare === 'ean') {
    return { mode, refKey: null, rows: [], all: [], unavailCheaper: [] };   // nema artikla s EAN-om u skupini
  } else if (group) {
    mode = 'opis';
    const best = new Map();
    for (const [k] of group.members) {
      const p = prods[k];
      if (!p) continue;
      for (const x of storeOffers(p, stores)) {
        const up = unitPrice(x.eff, p, group.base[0], group.kom_kao_pranje);
        if (!up) continue;
        const y = { ...x, prodKey: k, prod: p, up };
        const cur = best.get(x.si);
        const better = !cur || (cur.avail === 0 && y.avail !== 0) || ((y.avail !== 0 || cur.avail === 0) && y.up.value < cur.up.value);
        if (better) best.set(x.si, y);
      }
    }
    offers = [...best.values()];
  }
  if (opts.excludeStale) offers = offers.filter((x) => !x.stale);
  const key = mode === 'opis' ? (x) => x.up.value : (x) => x.eff;
  const sorted = offers.slice().sort((a, b) => key(a) - key(b) || (a.up?.value ?? 1e9) - (b.up?.value ?? 1e9) || distFn(a.store) - distFn(b.store));
  const ok = sorted.filter((x) => x.avail !== 0);
  const rows = collapse(ok, distFn).sort((a, b) => key(a) - key(b) || distFn(a.store) - distFn(b.store)).slice(0, 3);
  const unavailCheaper = rows.length ? sorted.filter((x) => x.avail === 0 && key(x) < key(rows[0])) : sorted.filter((x) => x.avail === 0);
  if (rows.length) {
    const b = key(rows[0]);
    const worst = Math.max(...ok.map(key));
    for (const r of rows) {
      r.diff = key(r) - b;
      r.diffPct = b ? r.diff / b : 0;
    }
    rows[0].maxSaving = worst - b;
    rows[0].maxSavingPct = worst ? (worst - b) / worst : 0;
  }
  return { mode, refKey, rows, all: sorted, unavailCheaper: collapse(unavailCheaper, distFn) };
}

/**
 * Pametne alternative: drugi artikli iste skupine (ili srodne skupine – veće pakiranje)
 * s nižom cijenom po jedinici od najbolje ponude referentnog artikla. Nikad isti EAN.
 */
export function alternatives(item, group, groupsById, prods, stores, distFn, refBest, opts = {}) {
  if (!group || !refBest || !refBest.up) return [];
  const refKey = refBest.prodKey;
  const ref = prods[refKey];
  const base = refBest.up.base;
  const cands = [];
  const seenKeys = new Set([refKey]);
  const pools = [[group, false], ...(group.alt || []).map((id) => [groupsById[id], true]).filter(([g]) => g)];
  for (const [g, bigger] of pools) {
    for (const [k] of g.members) {
      if (seenKeys.has(k)) continue;
      seenKeys.add(k);
      const p = prods[k];
      if (!p) continue;
      if (ref && ref.e && p.e === ref.e) continue;
      let offers = storeOffers(p, stores).filter((x) => x.avail !== 0);
      if (opts.excludeStale) offers = offers.filter((x) => !x.stale);
      if (!offers.length) continue;
      offers.sort((a, b) => a.eff - b.eff || distFn(a.store) - distFn(b.store));
      const best = offers[0];
      const up = unitPrice(best.eff, p, base, g.kom_kao_pranje);
      if (!up || up.value >= refBest.up.value * 0.99) continue;
      const refAmt = amountIn(ref || p, base, group.kom_kao_pranje) || 1;
      const saving = (refBest.up.value - up.value) * refAmt;
      cands.push({ prodKey: k, prod: p, best, up, saving, savingPct: 1 - up.value / refBest.up.value,
        groupLabel: g.label, bigger, sameCount: offers.length,
        reason: bigger
          ? `Ista vrsta proizvoda, veće pakiranje (${g.label}).`
          : `Ista skupina usporedivih proizvoda: ${g.label}. Usporedivo prema nazivu, vrsti i količini – ne nužno po ukupnoj kvaliteti.` });
    }
  }
  cands.sort((a, b) => a.up.value - b.up.value);
  return cands.slice(0, 3);
}

/** Najisplativije pakiranje u skupini (najniža cijena po jedinici, bilo koja veličina). */
export function bestValuePack(group, prods, stores, distFn) {
  if (!group) return null;
  let best = null;
  for (const [k] of group.members) {
    const p = prods[k];
    if (!p) continue;
    for (const x of storeOffers(p, stores)) {
      if (x.avail === 0) continue;
      const up = unitPrice(x.eff, p, group.base[0], group.kom_kao_pranje);
      if (up && (!best || up.value < best.up.value)) best = { ...x, prodKey: k, prod: p, up };
    }
  }
  return best;
}

// ------------------------------------------------------------------ košarica

/**
 * Trošak stavke u svakoj prodavaonici.
 * Vraća Map(si -> {cost, prodKey, packs, subst, approx}) i popis prodavaonica gdje je artikl nedostupan.
 */
export function itemCosts(item, group, groupsById, prods, stores, opts = {}) {
  const res = new Map();
  const unavailable = new Set();
  const qty = item.qty || 1;
  const refKey = referentKey(item, group, prods);
  const consider = (si, c) => {
    const cur = res.get(si);
    if (!cur || c.cost < cur.cost - 1e-9 || (Math.abs(c.cost - cur.cost) < 1e-9 && !c.subst && cur.subst)) res.set(si, c);
  };
  const skip = (x) => opts.excludeStale && x.stale;
  if (refKey) {
    const ref = prods[refKey];
    if (ref) {
      for (const x of storeOffers(ref, stores)) {
        if (skip(x)) continue;
        if (x.avail === 0) { unavailable.add(x.si); continue; }
        consider(x.si, { cost: x.eff * qty, unit: x.eff, prodKey: refKey, packs: qty, subst: false, approx: false, avail: x.avail });
      }
      if (opts.allowSubst && group) {
        const base = ref.q[Q.base] && group.base.includes(ref.q[Q.base]) ? ref.q[Q.base] : group.base[0];
        const refAmt = amountIn(ref, base, group.kom_kao_pranje);
        const pools = [group, ...(group.alt || []).map((id) => groupsById[id]).filter(Boolean)];
        if (refAmt) {
          for (const g of pools) {
            for (const [k] of g.members) {
              if (k === refKey) continue;
              const p = prods[k];
              if (!p) continue;
              const amt = amountIn(p, base, g.kom_kao_pranje);
              if (!amt) continue;
              const packs = Math.max(1, Math.round((qty * refAmt) / amt));
              for (const x of storeOffers(p, stores)) {
                if (skip(x) || x.avail === 0) continue;
                // zamjena samo ako u toj trgovini nema referentnog artikla ili je zamjena jeftinija za istu količinu
                consider(x.si, { cost: x.eff * packs, unit: x.eff, prodKey: k, packs, subst: true, approx: Math.abs(packs * amt - qty * refAmt) / (qty * refAmt) > 0.05, avail: x.avail });
              }
            }
          }
        }
      }
    }
  } else if (group) {
    // 'opis' – količina je u osnovnoj jedinici (npr. kg), trošak = cijena po jedinici × količina
    for (const [k] of group.members) {
      const p = prods[k];
      if (!p) continue;
      for (const x of storeOffers(p, stores)) {
        if (skip(x)) continue;
        if (x.avail === 0) { if (!res.has(x.si)) unavailable.add(x.si); continue; }
        const up = unitPrice(x.eff, p, group.base[0], group.kom_kao_pranje);
        if (!up) continue;
        consider(x.si, { cost: up.value * qty, unit: up.value, prodKey: k, packs: null, subst: false, approx: !p.q[Q.loose], avail: x.avail });
      }
    }
  }
  for (const si of res.keys()) unavailable.delete(si);
  return { costs: res, unavailable };
}

/** Prodavaonice s identičnim troškovima (isti cjenik lanca) svodi na najbližu. */
function dedupeStores(per, stores, distFn) {
  const sig = new Map();
  const allSi = new Set();
  per.forEach((it) => it.costs.forEach((_, si) => allSi.add(si)));
  for (const si of allSi) {
    const s = per.map((it) => (it.costs.has(si) ? `${it.costs.get(si).cost.toFixed(4)}:${it.costs.get(si).prodKey}` : '-')).join('|') + '#' + stores[si].chain;
    const cur = sig.get(s);
    if (cur == null || distFn(stores[si]) < distFn(stores[cur])) sig.set(s, si);
  }
  return [...sig.values()];
}

/**
 * Optimizacija košarice – scenariji A (jedna trgovina), B (svaki artikl najjeftiniji),
 * C (najviše k trgovina, k = 1, 2, 3).
 */
export function optimizeBasket(basket, groupsById, prods, stores, distFn, opts = {}) {
  const per = basket.map((it) => ({ item: it, ...itemCosts(it, groupsById[it.group], groupsById, prods, stores, opts) }));
  const notAnywhere = per.filter((x) => x.costs.size === 0).map((x) => x.item);
  const live = per.filter((x) => x.costs.size > 0);
  const cand = dedupeStores(live, stores, distFn);

  // ---- A: sve u jednoj trgovini
  const A = cand.map((si) => {
    let total = 0;
    const missing = [];
    const unavail = [];
    const lines = [];
    for (const x of live) {
      const c = x.costs.get(si);
      if (c) { total += c.cost; lines.push({ item: x.item, ...c }); }
      else if (x.unavailable.has(si)) unavail.push(x.item);
      else missing.push(x.item);
    }
    return { si, store: stores[si], total, missing, unavail, lines, complete: !missing.length && !unavail.length };
  }).sort((a, b) => (b.complete - a.complete) || (a.missing.length + a.unavail.length) - (b.missing.length + b.unavail.length) || a.total - b.total);
  const completeA = A.filter((a) => a.complete);

  // ---- B: svaki artikl tamo gdje je najjeftiniji
  const bLines = live.map((x) => {
    let best = null;
    for (const [si, c] of x.costs) {
      if (!best || c.cost < best.cost - 1e-9 || (Math.abs(c.cost - best.cost) < 1e-9 && distFn(stores[si]) < distFn(stores[best.si]))) best = { si, ...c };
    }
    return { item: x.item, ...best, store: stores[best.si] };
  });
  const bStores = [...new Set(bLines.map((l) => l.si))];
  const B = {
    total: bLines.reduce((a, l) => a + l.cost, 0),
    lines: bLines,
    stores: bStores.map((si) => ({ si, store: stores[si], lines: bLines.filter((l) => l.si === si), subtotal: bLines.filter((l) => l.si === si).reduce((a, l) => a + l.cost, 0) })),
  };
  B.savingVsA = completeA.length ? completeA[0].total - B.total : null;

  // ---- C: najviše k trgovina (iscrpna pretraga nad kandidatima)
  const top = new Set();
  live.forEach((x) => [...x.costs.entries()].filter(([si]) => cand.includes(si)).sort((a, b) => a[1].cost - b[1].cost).slice(0, 4).forEach(([si]) => top.add(si)));
  A.slice(0, 12).forEach((a) => top.add(a.si));
  const pool = [...top].slice(0, 40);
  const evalSet = (set) => {
    let total = 0;
    const lines = [];
    for (const x of live) {
      let best = null;
      for (const si of set) {
        const c = x.costs.get(si);
        if (c && (!best || c.cost < best.cost)) best = { si, ...c };
      }
      if (!best) return null;
      total += best.cost;
      lines.push({ item: x.item, ...best, store: stores[best.si] });
    }
    const used = [...new Set(lines.map((l) => l.si))];
    return { total, lines, stores: used.map((si) => stores[si]), sis: used };
  };
  const C = {};
  const kMax = opts.kMax || 3;
  for (let k = 1; k <= kMax; k++) {
    let best = null;
    const rec = (start, chosen) => {
      if (chosen.length === k) {
        const r = evalSet(chosen);
        if (r && (!best || r.total < best.total - 1e-9 || (Math.abs(r.total - best.total) < 1e-9 && r.sis.length < best.sis.length))) best = r;
        return;
      }
      for (let i = start; i < pool.length; i++) rec(i + 1, [...chosen, pool[i]]);
    };
    rec(0, []);
    if (best && best.sis.length < k && C[best.sis.length]) best = C[best.sis.length];
    C[k] = best;
  }
  C.unlimited = { total: B.total, lines: B.lines, stores: B.stores.map((s) => s.store), sis: bStores };

  return { per, notAnywhere, A, completeA, B, C };
}

/**
 * Preporuka: najmanje trgovina, osim ako dodatna trgovina štedi barem `minSaving` € (nakon troška puta ako je poznat).
 */
export function recommend(C, travel = {}, minSaving = 2) {
  const seen = new Set();
  const opts = [1, 2, 3, 'unlimited'].map((k) => C[k] && { k, ...C[k], travel: travel[k] ?? null }).filter((o) => {
    if (!o) return false;
    const sig = o.sis.slice().sort().join(',');   // isti skup trgovina = ista opcija
    if (seen.has(sig)) return false;
    seen.add(sig);
    return true;
  });
  if (!opts.length) return null;
  const total = (o) => o.total + (o.travel?.cost ?? 0);
  let rec = opts[0];
  for (const o of opts.slice(1)) {
    if (o.sis.length <= rec.sis.length) continue;
    if (total(rec) - total(o) >= minSaving) rec = o;
  }
  return { rec, opts, total };
}

/** Najkraća ruta (start -> trgovine -> start) iz matrice cestovnih udaljenosti (m). */
export function bestTour(matrix, idxs) {
  let best = null;
  const perm = (arr, l = 0) => {
    if (l === arr.length) {
      let d = 0, prev = 0;
      for (const i of arr) { const x = matrix[prev][i]; if (x == null) return; d += x; prev = i; }
      const back = matrix[prev][0]; if (back == null) return;
      d += back;
      if (!best || d < best.d) best = { d, order: arr.slice() };
      return;
    }
    for (let i = l; i < arr.length; i++) { [arr[l], arr[i]] = [arr[i], arr[l]]; perm(arr, l + 1); [arr[l], arr[i]] = [arr[i], arr[l]]; }
  };
  perm(idxs.slice());
  return best;
}

export function haversineKm(a, b) {
  const R = 6371.0088, r = Math.PI / 180;
  const dLat = (b.lat - a.lat) * r, dLon = (b.lon - a.lon) * r;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}
