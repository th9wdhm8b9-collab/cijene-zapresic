# Cijene Zaprešić – pametna usporedba cijena

Osobna web-aplikacija (prilagođena iPhoneu) koja svaki dan preuzima **službene javne cjenike** trgovaca
(Odluka o objavi cjenika) za prodavaonice u krugu od **15 km od središta Zaprešića** i za **METRO Jankomir 31**
(izričita iznimka) te prikazuje:

* tri najpovoljnije ponude za svaki vaš proizvod, s cijenom po kg / l / komadu / pranju,
* posebno istaknutu najnižu cijenu i najisplativije pakiranje,
* pametne alternative (druga marka ili veće pakiranje iste vrste),
* dostupnost: „NEMA NA ZALIHI — prema dostupnim podacima.” / „DOSTUPNOST NIJE POZNATA.”,
* optimizaciju košarice: A (jedna trgovina), B (svaki artikl najjeftiniji), C (najviše 1/2/3 trgovine) i trošak vožnje,
* pokrivenost i aktualnost podataka za svaki lanac i svaku poslovnicu,
* uz svaku cijenu izravnu poveznicu na službenu CSV/XML (ili ZIP) datoteku trgovca iz koje je cijena pročitana.

Službene poveznice čitaju se jednom dnevno, a mobitel učitava samo mali sažetak – zato se aplikacija otvara u nekoliko sekundi.

Nema API ključeva, pretplata ni izmišljenih cijena. Ako izvor ne radi, zadržavaju se posljednji valjani podaci
(najviše 30 dana) uz oznaku „potencijalno zastarjelo”.

---

## Postavljanje (jednom, ~10 minuta, besplatno) – GitHub

Dnevni uvoz pokreće **GitHub Actions**, a aplikacija se objavljuje na **GitHub Pages** (vaša web adresa).

1. Otvorite besplatan račun na <https://github.com> (ako ga nemate).
2. **New repository** → naziv npr. `cijene` → *Public* → **Create repository**.
   (GitHub Pages je besplatan za javne repozitorije. U repozitoriju je samo programski kod, bez osobnih podataka.
   Vaš popis proizvoda i košarica spremaju se samo na vašem mobitelu.)
3. Na stranici repozitorija: **Add file → Upload files** → povucite **sav sadržaj** raspakirane mape
   (mape `pipeline`, `docs`, `config`, `tests`, `.github` i ostale datoteke) → **Commit changes**.
   Ako mapa `.github` nije prenesena (skrivena mapa), napravite je ručno: **Add file → Create new file**,
   naziv `.github/workflows/dnevno-azuriranje.yml`, i zalijepite sadržaj te datoteke.
4. **Settings → Pages → Build and deployment → Source: GitHub Actions.**
5. **Actions** → *Dnevno ažuriranje cijena* → **Run workflow** (prvo pokretanje odmah).
   Prvi put traje dulje (15–40 min) jer se adrese poslovnica geokodiraju (OpenStreetMap, 1 upit/s).
6. Kad završi, adresa aplikacije je `https://<vaše-korisničko-ime>.github.io/cijene/`.
   Na iPhoneu: otvorite je u Safariju → **Podijeli → Dodaj na početni zaslon**.

Nakon toga uvoz se pokreće **automatski svaki dan u 8:25 (zimsko) / 9:25 (ljetno vrijeme)** i ponovno u 12:25/13:25
za trgovce koji kasne. Sažetak svakog pokretanja (pokrivenost, greške, broj artikala po skupini) vidi se u
**Actions → zadnje pokretanje → Summary**.

> GitHub isključuje zakazana pokretanja ako u repozitoriju 60 dana nema nikakve aktivnosti.
> Tada pošalje e-mail; dovoljno je u **Actions** kliknuti **Enable workflow**.

## Alternativa – na vlastitom računalu

```
pip install -r requirements.txt
python run_local.py          # preuzme cjenike i otvori aplikaciju na http://localhost:8000
```
Ažuriranje tada nije automatsko (može se zakazati u Windows Task Scheduleru), a mobitel aplikaciju vidi samo u istoj
kućnoj mreži.

---

## Kako radi

| Dio | Datoteka |
|---|---|
| Popis lanaca, izvori, lokacija, radijus, METRO iznimka | `config/settings.json` |
| Moduli izvora (jedan po načinu objave; novi trgovac = novi zapis/modul) | `pipeline/sources/` |
| Čitanje CSV / XML / ZIP, prepoznavanje stupaca po nazivu | `pipeline/parsing.py` |
| Normalizacija cijena, EAN/GTIN (kontrolni broj), količina, multipack, pranja | `pipeline/normalize.py` |
| Geokodiranje poslovnica i filtar radijusa | `pipeline/stores.py` |
| Početni katalog (20 proizvoda) i skupine usporedivih artikala | `pipeline/catalog.py` |
| Dnevni postupak, posljednji valjani podaci, objava | `pipeline/build.py` |
| Logika usporedbe, alternativa i košarice | `docs/logic.js` |
| Sučelje | `docs/index.html`, `docs/app.js`, `docs/style.css` |

**Pravila usporedbe**

* Isti artikl = isti **EAN/GTIN** (provjeren kontrolni broj; interni kodovi vaganih artikala 2xxxxx se ne koriste).
* Artikli bez EAN-a (voće, povrće, meso, pekara) uspoređuju se samo unutar skupine prema opisu i
  **označeni su kao nesigurni**.
* Skupine nikad ne miješaju različite vrste (npr. gauda ≠ svježi sir, trajno ≠ svježe mlijeko, 2,8 % ≠ 0,9 %).
* Jedinična cijena prikazuje se samo kad je količina pouzdano poznata.
* „Najniža cijena” = najmanji iznos za pakiranje; „Najisplativije pakiranje” = najniža cijena po jedinici.
* Dostupnost se prikazuje samo ako je cjenik izričito navodi (izmjena Odluke, NN 110/26, uvodi polje
  *dostupnost da/ne*). Cijena u cjeniku **ne** znači da je artikl na polici.
* Prodavaonica se uključuje ako je po koordinatama unutar 15 km; ako se adresa ne može geokodirati, koristi se
  središte mjesta samo kad je cijelo mjesto sigurno unutar radijusa. Ispravke: `config/stores_override.json`
  (`{"id-poslovnice": {"lat": 45.8, "lon": 15.8}}` – ID se vidi u zaslonu pokrivenosti).

## Testovi

```
python -m pytest -q
node --test tests/logic.test.mjs
```
Testovi koriste **umjetne** testne datoteke (`tests/fixture_server.py`) koje se nikad ne objavljuju.
Pokrivaju: isti EAN u više poslovnica, različite i akcijske cijene, pakiranja, multipackove, artikle bez EAN-a i bez
količine, nepoznatu i potvrđenu nedostupnost, zastarjele cjenike, nedostupan izvor, izvor koji traži prijavu,
izračun uštede, optimizaciju košarice, poslovnice unutar/izvan radijusa i METRO iznimku.
