"""Pokretanje na vlastitom računalu (Windows/macOS/Linux):

    pip install -r requirements.txt
    python run_local.py            # preuzme današnje cjenike i otvori aplikaciju na http://localhost:8000
    python run_local.py --serve    # samo pokrene aplikaciju s već preuzetim podacima
"""
import functools, http.server, socketserver, sys, webbrowser
from pathlib import Path
from pipeline import build, report

ROOT = Path(__file__).resolve().parent
if "--serve" not in sys.argv:
    code = build.main([])
    report.main()
    if code not in (0, 3):
        sys.exit(code)
handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(ROOT / "docs"))
with socketserver.TCPServer(("0.0.0.0", 8000), handler) as s:
    print("Aplikacija: http://localhost:8000  (Ctrl+C za kraj)")
    webbrowser.open("http://localhost:8000")
    s.serve_forever()
