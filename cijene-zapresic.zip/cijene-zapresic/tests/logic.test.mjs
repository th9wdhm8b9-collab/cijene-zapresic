// node --test tests/logic.test.mjs   (umjetni testni podaci – ne ulaze u aplikaciju)
import test from 'node:test';
import assert from 'node:assert/strict';
import * as L from '../docs/logic.js';

const st = (id, chain, lat, lon, extra = {}) => ({ id, chain, chain_name: chain, address: id, city: 'T', lat, lon, dist_km: 1, ...extra });
const stores = [
  st('kz1', 'konzum', 45.86, 15.81),            // 0
  st('kz2', 'konzum', 45.80, 15.71),            // 1
  st('li1', 'lidl', 45.85, 15.80),              // 2
  st('sp1', 'spar', 45.84, 15.85, { stale: true }), // 3 zastarjelo
  st('st1', 'studenac', 45.857, 15.807),        // 4
];
const center = { lat: 45.8566, lon: 15.8078 };
const dist = (s) => L.haversineKm(center, s);
const P = (n, e, q, o) => ({ n, b: '', e, cat: '', g: [], q, o });
const q = (base, amount, extra = {}) => [base, amount, extra.count ?? null, extra.per ?? null, extra.washes ?? null, extra.loose ? 1 : 0, 'polje'];
//            p     s     l30  a     st    up    w     stores
const prods = {
  'e:milkA': P('Mlijeko A 2,8% 1 l', '1', q('l', 1), [[1.29, null, null, null, null, null, null, [0, 1]], [1.19, null, null, 1, null, null, null, [4]], [1.35, 0.99, null, 0, null, null, null, [3]]]),
  'e:milkL': P('Mlijeko Lidl 2,8% 1 l', '2', q('l', 1), [[0.95, null, null, 1, null, null, null, [2]]]),
  'e:milkB': P('Mlijeko B 2,8% 1 l', '3', q('l', 1), [[1.25, null, null, null, null, null, null, [0]]]),
  'e:butter250': P('Maslac 250 g', '4', q('kg', 0.25), [[2.50, null, null, null, null, null, null, [0, 1, 2]], [2.20, null, null, null, null, null, null, [4]]]),
  'e:butter125': P('Maslac 125 g', '5', q('kg', 0.125), [[1.20, null, null, null, null, null, null, [0]], [1.40, null, null, null, null, null, null, [2]]]),
  'c:konzum:ban': P('Banane', null, q('kg', 1, { loose: true }), [[1.49, null, null, null, null, null, null, [0, 1]]]),
  'c:lidl:ban': P('Banane', null, q('kg', 1, { loose: true }), [[1.29, null, null, null, null, null, null, [2]]]),
  'e:det': P('Gel 4x15 pranja', '6', q('l', 3, { count: 4, per: 0.75, washes: 60 }), [[9.99, null, null, 1, null, null, null, [2]]]),
  'e:det2': P('Deterdžent 40 pranja', '7', q('l', 2, { washes: 40 }), [[11.99, 8.99, null, null, null, null, null, [0]]]),
  'e:noqty': P('Bez količine', '8', [null, null, null, null, null, 0, null], [[2.0, null, null, null, null, null, null, [4]]]),
};
const groups = {
  'mlijeko-trajno-28': { id: 'mlijeko-trajno-28', label: 'Trajno mlijeko 2,8 %', compare: 'ean', base: ['l'], members: [['e:milkA', 0], ['e:milkL', 0], ['e:milkB', 0]] },
  'maslac-125': { id: 'maslac-125', label: 'Maslac 125 g', compare: 'ean', base: ['kg'], alt: ['maslac-250'], members: [['e:butter125', 0]] },
  'maslac-250': { id: 'maslac-250', label: 'Maslac 250 g', compare: 'ean', base: ['kg'], members: [['e:butter250', 0]] },
  banane: { id: 'banane', label: 'Banane', compare: 'opis', base: ['kg'], members: [['c:konzum:ban', 0], ['c:lidl:ban', 0]] },
  'det-tekuci': { id: 'det-tekuci', label: 'Deterdžent', compare: 'ean', base: ['pranje'], members: [['e:det', 0], ['e:det2', 0]] },
};

test('jedinične cijene i pakiranja', () => {
  assert.equal(L.unitPrice(1.20, P('x', '', q('kg', 0.5), []), 'kg').value, 2.4);
  assert.equal(L.unitPrice(2.10, P('x', '', q('kg', 1), []), 'kg').value, 2.1);
  assert.equal(L.unitPrice(1.20, P('x', '', q('kg', 0.5), []), 'kg').small.value.toFixed(2), '0.24');
  assert.equal(L.unitPrice(9.99, prods['e:det'], 'pranje').value.toFixed(4), (9.99 / 60).toFixed(4));
  assert.equal(L.unitPrice(2, prods['e:noqty']), null);            // nema količine -> nema jedinične cijene
  assert.match(L.packLabel(prods['e:det']), /4 × 750 ml \(3 l\) · 60 pranja/);
  assert.equal(L.eur(1.5).replace(/\s/g, ' '), '1,50 €');
});

test('top 3: isti EAN, akcija, nedostupnost, zastarjelo', () => {
  const item = { id: 'mlijeko', group: 'mlijeko-trajno-28', pick: 'e:milkA' };
  const r = L.topOffers(item, groups['mlijeko-trajno-28'], prods, stores, dist);
  assert.equal(r.mode, 'ean');
  // Spar 0,99 je NEDOSTUPAN -> ne smije biti u top 3, ali se prijavljuje kao jeftiniji-nedostupan
  assert.deepEqual(r.rows.map((x) => x.eff), [1.19, 1.29]);
  assert.equal(r.rows[0].store.id, 'st1');
  assert.equal(r.rows[1].others.length, 1);                      // dvije Konzum poslovnice s istom cijenom spojene
  assert.equal(r.rows[1].store.id, 'kz1');                       // najbliža prva
  assert.equal(r.unavailCheaper.length, 1);
  assert.equal(r.unavailCheaper[0].store.id, 'sp1');
  assert.ok(Math.abs(r.rows[1].diff - 0.10) < 1e-9);
  assert.ok(Math.abs(r.rows[0].maxSaving - 0.10) < 1e-9);
  // bez zastarjelih podataka
  const r2 = L.topOffers(item, groups['mlijeko-trajno-28'], prods, stores, dist, { excludeStale: true });
  assert.equal(r2.unavailCheaper.length, 0);
});

test('automatski referentni artikl = najrasprostranjeniji EAN', () => {
  assert.equal(L.referentKey({ group: 'mlijeko-trajno-28' }, groups['mlijeko-trajno-28'], prods), 'e:milkA');
});

test('nikad ne izmišlja treću ponudu', () => {
  const r = L.topOffers({ pick: 'e:milkB' }, groups['mlijeko-trajno-28'], prods, stores, dist);
  assert.equal(r.rows.length, 1);
});

test('pametne alternative: druga marka i veće pakiranje, nikad isti EAN', () => {
  const item = { pick: 'e:milkA', group: 'mlijeko-trajno-28' };
  const g = groups['mlijeko-trajno-28'];
  const t = L.topOffers(item, g, prods, stores, dist);
  const alts = L.alternatives(item, g, groups, prods, stores, dist, t.rows[0]);
  assert.deepEqual(alts.map((a) => a.prodKey), ['e:milkL']);      // B (1,25) nije jeftiniji od 1,19
  assert.ok(Math.abs(alts[0].saving - 0.24) < 1e-9);
  assert.ok(alts[0].reason.includes('ne nužno po ukupnoj kvaliteti'));
  const b = { pick: 'e:butter125', group: 'maslac-125' };
  const tb = L.topOffers(b, groups['maslac-125'], prods, stores, dist);
  assert.equal(tb.rows[0].up.value, 9.6);                          // 1,20 € / 0,125 kg
  const ab = L.alternatives(b, groups['maslac-125'], groups, prods, stores, dist, tb.rows[0]);
  assert.equal(ab[0].prodKey, 'e:butter250');                      // 2,20/0,25 = 8,80 €/kg < 9,60 €/kg
  assert.ok(ab[0].bigger);
  assert.ok(Math.abs(ab[0].saving - 0.10) < 1e-9);                 // (9,60-8,80) × 0,125 kg
});

test('najniža cijena vs. najisplativije pakiranje (deterdžent po pranju)', () => {
  const g = groups['det-tekuci'];
  const bv = L.bestValuePack(g, prods, stores, dist);
  assert.equal(bv.prodKey, 'e:det');      // 9,99/60 = 0,1665 < 8,99/40 = 0,2248
  const t = L.topOffers({ pick: 'e:det2', group: 'det-tekuci' }, g, prods, stores, dist);
  assert.equal(t.rows[0].eff, 8.99);      // akcijska cijena
  assert.equal(t.rows[0].special, 8.99);
});

test("'opis' način (bez EAN-a): banane po kg, označeno nesigurno", () => {
  const r = L.topOffers({ group: 'banane' }, groups.banane, prods, stores, dist);
  assert.equal(r.mode, 'opis');
  assert.deepEqual(r.rows.map((x) => x.eff), [1.29, 1.49]);
});

test('košarica: scenariji A, B, C i preporuka', () => {
  const basket = [
    { id: 'mlijeko', group: 'mlijeko-trajno-28', pick: 'e:milkA', qty: 2 },
    { id: 'banane', group: 'banane', qty: 1.5 },
    { id: 'maslac', group: 'maslac-250', pick: 'e:butter250', qty: 1 },
  ];
  const strict = L.optimizeBasket(basket, groups, prods, stores, dist, { allowSubst: false });
  // A: Konzum ima sve: 2×1,29 + 1,5×1,49 + 2,50 = 7,315
  const kz = strict.completeA[0];
  assert.equal(kz.store.chain, 'konzum');
  assert.ok(Math.abs(kz.total - 7.315) < 1e-9);
  // Lidl nema mlijeko A (strogo) -> nepotpun
  assert.ok(strict.A.find((a) => a.store.chain === 'lidl').missing.length === 1);
  // Spar: mlijeko nedostupno -> u popisu nedostupnih
  // B: mlijeko Studenac 2×1,19, banane Lidl 1,5×1,29, maslac Studenac 2,20
  assert.ok(Math.abs(strict.B.total - (2.38 + 1.935 + 2.20)) < 1e-9);
  assert.equal(strict.B.stores.length, 2);
  assert.ok(Math.abs(strict.B.savingVsA - (7.315 - 6.515)) < 1e-9);
  assert.ok(Math.abs(strict.C[1].total - 7.315) < 1e-9);
  assert.ok(Math.abs(strict.C[2].total - 6.515) < 1e-9);
  assert.equal(strict.C[3].sis.length, 2);
  // preporuka: ušteda 0,80 € < 2 € -> jedna trgovina
  const rec = L.recommend(strict.C, {}, 2);
  assert.equal(rec.rec.sis.length, 1);
  assert.equal(L.recommend(strict.C, {}, 0.5).rec.sis.length, 2);
  // trošak puta može preokrenuti preporuku
  assert.equal(L.recommend(strict.C, { 1: { cost: 0.3 }, 2: { cost: 1.2 } }, 0.5).rec.sis.length, 1);

  // sa zamjenama: Lidl postaje potpun (Lidl mlijeko) i najjeftiniji
  const subst = L.optimizeBasket(basket, groups, prods, stores, dist, { allowSubst: true });
  const lidl = subst.A.find((a) => a.store.chain === 'lidl');
  assert.ok(lidl.complete);
  assert.ok(lidl.lines.find((l) => l.item.id === 'mlijeko').subst);
  assert.ok(Math.abs(lidl.total - (1.90 + 1.935 + 2.50)) < 1e-9);
});

test('artikl koji nema nigdje', () => {
  const r = L.optimizeBasket([{ id: 'x', group: 'nema', pick: 'e:nepostoji', qty: 1 }], groups, prods, stores, dist, {});
  assert.equal(r.notAnywhere.length, 1);
});

test('ruta: najkraći obilazak', () => {
  const m = [[0, 5, 9], [5, 0, 3], [9, 3, 0]];
  assert.equal(L.bestTour(m, [1, 2]).d, 17);
});
