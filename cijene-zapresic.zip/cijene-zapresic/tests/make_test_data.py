"""Stvara UMJETNI testni skup podataka za provjeru sučelja (nikad se ne objavljuje)."""
import datetime as dt, json, sys
from pathlib import Path
from unittest import mock
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from pipeline import build
from pipeline.stores import Geocoder
from pipeline.normalize import fold
from tests import fixture_server as fx
from tests.test_pipeline import COORDS

out = Path(sys.argv[1])
srv = fx.start(); base = f"http://127.0.0.1:{srv.server_port}"
ROOT = Path(__file__).resolve().parent.parent
S = json.loads((ROOT/"config/settings.json").read_text("utf-8"))
S["chains"] = {
  "konzum": {"name": "Konzum", "module": "konzum", "url": f"{base}/konzum/cjenici"},
  "lidl": {"name": "Lidl", "module": "generic", "url": f"{base}/lidl/cijene"},
  "studenac": {"name": "Studenac", "module": "generic", "url": f"{base}/studenac/"},
  "metro": {"name": "METRO Cash & Carry", "module": "generic", "url": f"{base}/metro/", "note": S["chains"]["metro"]["note"]},
  "zatvoreni": {"name": "Izvor s prijavom (test)", "module": "generic", "url": f"{base}/login-only/"},
}
sp = out.parent / "test_settings.json"; sp.write_text(json.dumps(S), "utf-8")
def loc(self, sid, a, p, c):
    for k,(la,lo) in COORDS.items():
        if fold(k)==fold(a): return {"lat":la,"lon":lo,"precision":"adresa"}
with mock.patch.object(Geocoder, "locate", loc):
    build.run(sp, out, out.parent/"test_state", today=dt.date.today(), geocode=False)
srv.shutdown()
