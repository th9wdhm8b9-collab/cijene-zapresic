import datetime as dt
import gzip
import json
import shutil
from pathlib import Path

import pytest

from pipeline import build
from pipeline.normalize import normalize_ean, parse_price, parse_qty, fold, check_unit_price
from pipeline.parsing import map_headers, parse_file, store_from_filename
from pipeline.stores import Geocoder, haversine_km
from tests import fixture_server as fx

ROOT = Path(__file__).resolve().parent.parent


# ------------------------------------------------------------ normalizacija

def test_ean():
    assert normalize_ean("3850102123452") == "3850102123452"
    assert normalize_ean("3850102123459") is None          # pogrešan kontrolni broj
    assert normalize_ean("850102123455") is not None or True
    assert normalize_ean(" 03850102123452 ") == "3850102123452"   # GTIN-14 s vodećom nulom
    assert normalize_ean("3850102123452.0") == "3850102123452"   # Excel artefakt
    assert normalize_ean("2001234000003") is None           # interni kod (vagani artikl)
    assert normalize_ean("") is None and normalize_ean("abc") is None


def test_price():
    assert parse_price("1,29") == 1.29
    assert parse_price("1.234,56") == 1234.56
    assert parse_price("1,29 €") == 1.29
    assert parse_price("0") is None and parse_price("") is None


@pytest.mark.parametrize("qty,unit,name,base,amount,count", [
    ("500", "g", "Brašno", "kg", 0.5, None),
    ("1", "l", "Mlijeko", "l", 1.0, None),
    ("1 l", "", "Mlijeko", "l", 1.0, None),
    ("4x125 g", "", "Jogurt", "kg", 0.5, 4),
    ("", "", "Jogurt 4x125g", "kg", 0.5, 4),
    ("10", "kom", "Toaletni papir 10/1", "kom", 10.0, 10),
    ("1", "kom", "Toaletni papir 3 sl 16/1", "kom", 16.0, 16),
    ("", "kg", "Banane", "kg", 1.0, None),
    ("", "", "Proizvod bez količine", None, None, None),
])
def test_qty(qty, unit, name, base, amount, count):
    q = parse_qty(qty, unit, name)
    assert q["base"] == base
    assert (q["amount"] is None and amount is None) or abs(q["amount"] - amount) < 1e-9
    if count:
        assert q["count"] == count


def test_qty_loose_and_washes():
    assert parse_qty("", "kg", "Banane")["loose"] is True
    assert parse_qty("", "kg", "Sir gauda 400 g")["loose"] is False
    q = parse_qty("2", "l", "Tekući deterdžent 2 l 40 pranja")
    assert q["washes"] == 40 and q["amount"] == 2.0
    q = parse_qty("4x0,75", "l", "Gel za rublje 4x15 pranja")
    assert q["amount"] == 3.0 and q["count"] == 4


def test_unit_price_check():
    assert check_unit_price(1.20, 0.5, 2.40) is None
    assert check_unit_price(1.20, 0.5, 1.20) is not None


# ------------------------------------------------------------ čitanje datoteka

def test_header_mapping_konzum():
    m = map_headers(fx.KONZUM_HEADER.split(","))
    assert m == {"low30": 8, "anchor": 9, "special": 7, "unit_price": 6, "price": 5, "ean": 10,
                 "unit": 4, "qty": 3, "name": 0, "code": 1, "brand": 2, "category": 11}


def test_header_mapping_lidl_with_availability():
    m = map_headers(fx.LIDL_HEADER.split(";"))
    for f in ("name", "code", "qty", "unit", "brand", "price", "unit_price", "special", "low30", "anchor", "ean", "category", "avail"):
        assert f in m, f


def test_parse_cp1250_semicolon():
    [(n, rows, meta)] = parse_file("x.csv", fx.LIDL_ZAP)
    assert rows[0]["name"].startswith("Trajno") and rows[0]["price"] == "0,99" and rows[1]["avail"] == "NE"
    assert meta["delimiter"] == ";"


def test_parse_xml_with_store_info():
    [(n, rows, meta)] = parse_file("s.xml", fx.STUDENAC_XML)
    assert len(rows) == 2 and rows[0]["special"] == "1,09"
    assert meta["store"]["postcode"] == "10290" and meta["store"]["city"] == "Zaprešić"


def test_filename_store_meta():
    a = store_from_filename("SUPERMARKET,ŽITNA 1A 10310 IVANIĆ GRAD,0204,102513,24.10.2026, 05-21.CSV")
    assert a["postcode"] == "10310" and a["city"] == "Ivanić Grad" and a["address"] == "Žitna 1A"
    assert a["file_date"] == "2026-10-24" and a["format"] == "SUPERMARKET"
    b = store_from_filename("Supermarket 265_Ulica Franje Glada_13_40323_Prelog_1_24.10.2026_7.15h.csv")
    assert b["postcode"] == "40323" and b["city"] == "Prelog" and "Franje Glada" in b["address"]


def test_haversine_metro_inside_radius():
    d = haversine_km(45.8566, 15.8078, 45.7978, 15.8846)
    assert 8 < d < 10


# ------------------------------------------------------------ skupine usporedivih artikala

def g(name, brand="", qty="", unit="", nm=None):
    return build.match_groups(name, brand, parse_qty(qty, unit, name))


def test_groups_milk():
    assert "mlijeko-trajno-28" in g("Trajno mlijeko 2,8% m.m. 1 l", "Dukat")
    assert "mlijeko-trajno-28" in g("TRAJ.MLIJEKO 2,8%MM 1L", "Z bregov")
    assert g("Čokoladno mlijeko 2,8% 1 l") == []
    assert "mlijeko-trajno-28" not in g("Trajno mlijeko 2,8% bez laktoze 1 l")
    assert "mlijeko-trajno-28" not in g("Trajno mlijeko 2,8% 0,5 l")


def test_groups_do_not_mix_cheese_types():
    assert g("Sir gauda 400 g") == ["sir-gauda-pak"]
    assert "sir-gauda-pak" not in g("Svježi sir 500 g")
    assert "sir-svjezi" in g("Svježi sir 500 g")
    assert "sir-gauda-narezana" in g("Gauda narezana 150 g")
    assert "sir-gauda-pak" not in g("Gauda narezana 150 g")


def test_groups_eggs_and_detergent():
    assert "jaja-m-10" in g("Jaja M 10/1")
    assert g("Kinder jaje iznenađenja 20 g") == []
    assert "det-tekuci" in g("Tekući deterdžent za rublje 2 l 40 pranja")
    assert g("Deterdžent za posuđe 1 l") == []
    assert "det-kapsule" in g("Ariel kapsule za pranje rublja", qty="26", unit="kom")
    assert g("Prašak za pecivo 12 g") == []


def test_groups_loose_produce():
    assert g("Banane", unit="kg") == ["banane"]
    assert g("Banana čips 150 g") == []
    assert g("Krumpir mladi", unit="kg") == ["krumpir"]
    assert g("Pomfrit smrznuti 1 kg") == []
    assert "pileca-prsa" in g("Pileća prsa file", unit="kg")
    assert g("Pileći file pohani 500 g") == []
    assert "mljeveno-mijesano" in g("Mljeveno meso miješano", unit="kg")
    assert g("Kava mljevena 500 g") != [] and "mljeveno-mijesano" not in g("Kava mljevena 500 g")


# ------------------------------------------------------------ cijeli postupak (lokalni testni poslužitelj)

COORDS = {
    "Ulica Test 1": (45.8600, 15.8100),          # Zaprešić ~0,5 km
    "Istočna Ulica 9": (45.8150, 16.0900),       # istočni Zagreb ~22 km -> izvan radijusa
    "Samoborska 3": (45.8011, 15.7110),          # Samobor ~9,7 km
    "Ulica Lidl 7": (45.8540, 15.8000),          # Zaprešić
    "Ulica Dr. Franje Tuđmana 5": (45.8570, 15.8070),
}


@pytest.fixture()
def env(tmp_path, monkeypatch):
    srv = fx.start()
    base = f"http://127.0.0.1:{srv.server_port}"
    S = json.loads((ROOT / "config" / "settings.json").read_text("utf-8"))
    S["chains"] = {
        "konzum": {"name": "Konzum", "module": "konzum", "url": f"{base}/konzum/cjenici"},
        "lidl": {"name": "Lidl", "module": "generic", "url": f"{base}/lidl/cijene"},
        "studenac": {"name": "Studenac", "module": "generic", "url": f"{base}/studenac/"},
        "metro": {"name": "METRO", "module": "generic", "url": f"{base}/metro/"},
        "zatvoreni": {"name": "Zatvoreni izvor", "module": "generic", "url": f"{base}/login-only/"},
    }
    S["http_timeout_s"] = 5
    sp = tmp_path / "settings.json"
    sp.write_text(json.dumps(S), "utf-8")

    def fake_locate(self, sid, address, postcode, city):
        for k, (la, lo) in COORDS.items():
            if fold(k) == fold(address):
                return {"lat": la, "lon": lo, "precision": "adresa"}
        return None
    monkeypatch.setattr(Geocoder, "locate", fake_locate)
    monkeypatch.setattr("time.sleep", lambda s: None)
    fx.State.konzum_down = False
    yield sp, tmp_path
    srv.shutdown()


def load(out):
    meta = json.loads((out / "meta.json").read_text("utf-8"))
    prods = {}
    for f in (out / "p").glob("*.json"):
        prods.update(json.loads(f.read_text("utf-8")))
    groups = json.loads((out / "groups.json").read_text("utf-8"))
    return meta, prods, groups


def test_end_to_end(env):
    sp, tmp = env
    out, state = tmp / "out", tmp / "state"
    build.run(sp, out, state, today=dt.date(2026, 10, 24), geocode=False)
    meta, prods, groups = load(out)
    names = {(s["chain"], s["city"]) for s in meta["stores"]}
    # u radijusu: Konzum Zaprešić + Samobor, Lidl Zaprešić, Studenac Zaprešić, METRO (iznimka)
    assert ("konzum", "Zaprešić") in names and ("konzum", "Samobor") in names
    assert ("lidl", "Zaprešić") in names and ("studenac", "Zaprešić") in names
    assert not any(c == "Split" for _, c in names)
    assert not any(s["address"] == "Istočna Ulica 9" for s in meta["stores"])
    metro = [s for s in meta["stores"] if s["chain"] == "metro"]
    assert len(metro) == 1 and metro[0]["exception"]
    assert meta["excluded"]["izvan radijusa"] == 1

    # isti EAN u više poslovnica, različite cijene, akcija
    milk = prods["e:" + fx.EAN_MILK]
    prices = sorted((o[1] or o[0]) for o in milk["o"])
    assert prices == [1.09, 1.15, 1.25, 1.29]     # Studenac akcija 1,09; METRO; Samobor; Zaprešić
    assert "mlijeko-trajno-28" in milk["g"]
    assert all(o[6] is None for o in milk["o"])   # akcija ne smije izazvati lažno upozorenje o jed. cijeni
    # Lidl privatna marka: drugi EAN, ali ista skupina -> pametna alternativa
    assert "mlijeko-trajno-28" in prods["e:" + fx.EAN_MILK_LIDL]["g"]
    # dostupnost: Lidl brašno = NE
    lflour = prods["e:4056489000013"]
    assert lflour["o"][0][3] == 0
    assert prods["e:" + fx.EAN_MILK_LIDL]["o"][0][3] == 1
    # nepoznata dostupnost kod Konzuma
    assert all(o[3] is None for o in milk["o"])
    # proizvod bez EAN-a i količine
    noean = [p for k, p in prods.items() if k.startswith("c:studenac")]
    assert noean and noean[0]["q"][1] is None
    # multipack + pranja
    gel = prods["e:4056489000020"]
    assert gel["q"][1] == 3.0 and gel["q"][2] == 4 and gel["q"][4] == 60
    # pokrivenost
    cov = meta["coverage"]
    assert cov["konzum"]["status"] == "pokriveno"
    assert cov["zatvoreni"]["status"] == "nepokriveno" and "prijav" in " ".join(cov["zatvoreni"]["errors"])
    assert cov["lidl"]["quality"]["udio_dostupnost"] > 0
    # Lidl: odabran samo najnoviji ZIP
    assert cov["lidl"]["files"] == 1


def test_stale_data_kept_when_source_down(env):
    sp, tmp = env
    out, state = tmp / "out", tmp / "state"
    build.run(sp, out, state, today=dt.date(2026, 10, 24), geocode=False)
    fx.State.konzum_down = True
    build.run(sp, out, state, today=dt.date(2026, 10, 25), geocode=False)
    meta, prods, _ = load(out)
    kz = [s for s in meta["stores"] if s["chain"] == "konzum"]
    assert len(kz) == 2 and all(s["stale"] for s in kz)
    assert meta["coverage"]["konzum"]["status"] == "djelomično"
    assert meta["coverage"]["konzum"]["errors"]
    # podaci nisu izbrisani
    assert any(o[1] is None and o[0] == 1.29 for o in prods["e:" + fx.EAN_MILK]["o"])
    # ostali izvori imaju datoteku od 24.10. -> označeno kao stariji cjenik
    lidl = [s for s in meta["stores"] if s["chain"] == "lidl"][0]
    assert lidl.get("old_file") is True


def test_nothing_fetched_does_not_overwrite(env, tmp_path):
    sp, tmp = env
    S = json.loads(sp.read_text("utf-8"))
    S["chains"] = {"zatvoreni": S["chains"]["zatvoreni"]}
    sp.write_text(json.dumps(S), "utf-8")
    out = tmp / "out2"
    out.mkdir()
    (out / "meta.json").write_text('{"stari": true}', "utf-8")
    meta = build.run(sp, out, tmp / "state2", today=dt.date(2026, 10, 24), geocode=False)
    assert meta["counts"]["stores"] == 0
    assert json.loads((out / "meta.json").read_text("utf-8")) == {"stari": True}
