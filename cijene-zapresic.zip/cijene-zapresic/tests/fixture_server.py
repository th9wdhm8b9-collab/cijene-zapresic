"""Lokalni testni poslužitelj s UMJETNIM cjenicima (samo za testove – ne ulaze u aplikaciju)."""
from __future__ import annotations

import io
import threading
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, quote

KONZUM_HEADER = ("NAZIV PROIZVODA,ŠIFRA PROIZVODA,MARKA PROIZVODA,NETO KOLIČINA,JEDINICA MJERE,MALOPRODAJNA CIJENA,"
                 "CIJENA ZA JEDINICU MJERE,MPC ZA VRIJEME POSEBNOG OBLIKA PRODAJE,NAJNIŽA CIJENA U POSLJEDNJIH 30 DANA,"
                 "SIDRENA CIJENA NA 2.5.2025,BARKOD,KATEGORIJA PROIZVODA")


def konzum_csv(rows):
    lines = [KONZUM_HEADER] + [",".join(f'"{c}"' for c in r) for r in rows]
    return ("\n".join(lines) + "\n").encode("utf-8")


# EAN-ovi s ispravnim kontrolnim brojem (izmišljeni za test)
EAN_MILK = "3850102123452"
EAN_MILK_LIDL = "4056489123453"
EAN_FLOUR = "3850104000010"
EAN_DET = "8001090000019"
EAN_TP = "3830001000016"

KZ_ZAP = konzum_csv([
    ["TEST Trajno mlijeko 2,8% m.m. 1 l", "1001", "TestDukat", "1", "l", "1.29", "1.29", "", "1.19", "1.35", EAN_MILK, "Mlijeko"],
    ["TEST Čokoladno mlijeko 2,8% 1 l", "1002", "TestDukat", "1", "l", "1.79", "1.79", "", "", "", "3850102000012", "Mlijeko"],
    ["TEST Brašno pšenično glatko T-550 1 kg", "1003", "TestFlour", "1", "kg", "0.99", "0.99", "0.79", "", "", EAN_FLOUR, "Brašno"],
    ["TEST Banane", "1004", "", "", "kg", "1.49", "1.49", "", "", "", "", "Voće"],
    ["TEST Toaletni papir 3 sloja 10/1", "1005", "TestRoll", "10", "kom", "4.99", "0.50", "", "", "", EAN_TP, "Higijena"],
    ["TEST Tekući deterdžent za rublje 2 l 40 pranja", "1006", "TestWash", "2", "l", "11.99", "6.00", "8.99", "", "", EAN_DET, "Kućanstvo"],
])
KZ_ZG_EAST = konzum_csv([
    ["TEST Trajno mlijeko 2,8% m.m. 1 l", "1001", "TestDukat", "1", "l", "1.19", "1.19", "", "", "", EAN_MILK, "Mlijeko"],
])
KZ_SAM = konzum_csv([
    ["TEST Trajno mlijeko 2,8% m.m. 1 l", "1001", "TestDukat", "1", "l", "1.25", "1.25", "", "", "", EAN_MILK, "Mlijeko"],
    ["TEST Brašno pšenično glatko T-550 1 kg", "1003", "TestFlour", "1", "kg", "0.95", "0.95", "", "", "", EAN_FLOUR, "Brašno"],
    ["TEST Banane", "1004", "", "", "kg", "1.39", "1.39", "", "", "", "", "Voće"],
])

LIDL_HEADER = ("NAZIV;ŠIFRA;NETO_KOLIČINA;JEDINICA_MJERE;MARKA;MALOPRODAJNA_CIJENA;CIJENA_ZA_JEDINICU_MJERE;"
               "MPC_ZA_VRIJEME_POSEBNOG_OBLIKA_PRODAJE;NAJNIZA_CIJENA_U_POSLJ._30_DANA;Sidrena_cijena_na_2.5.2025;BARKOD;"
               "KATEGORIJA_PROIZVODA;DOSTUPNOST")


def lidl_csv(rows):
    return ("\r\n".join([LIDL_HEADER] + [";".join(r) for r in rows]) + "\r\n").encode("cp1250")


LIDL_ZAP = lidl_csv([
    ["Trajno mlijeko 2,8 % m.m.", "L1", "1 l", "l", "TestPilos", "0,99", "0,99", "", "", "", EAN_MILK_LIDL, "Mlijeko", "DA"],
    ["Brašno pšenično glatko T-550", "L2", "1", "kg", "TestBelbake", "0,69", "0,69", "", "", "", "4056489000013", "Brašno", "NE"],
    ["Banane", "L3", "1", "kg", "", "1,29", "1,29", "", "", "", "", "Voće", ""],
    ["Gel za rublje 4x15 pranja", "L4", "4x0,75", "l", "TestFormil", "9,99", "3,33", "", "", "", "4056489000020", "Kućanstvo", "DA"],
])
LIDL_SPLIT = lidl_csv([
    ["Trajno mlijeko 2,8 % m.m.", "L1", "1 l", "l", "TestPilos", "0,89", "0,89", "", "", "", EAN_MILK_LIDL, "Mlijeko", "DA"],
])

STUDENAC_XML = """<?xml version="1.0" encoding="UTF-8"?>
<Proizvodi>
  <ProdajniObjekt><Adresa>Ulica Dr. Franje Tuđmana 5</Adresa><PostanskiBroj>10290</PostanskiBroj><Grad>Zaprešić</Grad></ProdajniObjekt>
  <Proizvod><NazivProizvoda>TEST Trajno mlijeko 2,8% m.m. 1 l</NazivProizvoda><SifraProizvoda>S1</SifraProizvoda><MarkaProizvoda>TestDukat</MarkaProizvoda>
    <NetoKolicina>1</NetoKolicina><JedinicaMjere>l</JedinicaMjere><MaloprodajnaCijena>1,35</MaloprodajnaCijena><CijenaZaJedinicuMjere>1,35</CijenaZaJedinicuMjere>
    <MaloprodajnaCijenaAkcija>1,09</MaloprodajnaCijenaAkcija><Barkod>{milk}</Barkod></Proizvod>
  <Proizvod><NazivProizvoda>TEST Proizvod bez barkoda i količine</NazivProizvoda><SifraProizvoda>S2</SifraProizvoda><MarkaProizvoda></MarkaProizvoda>
    <NetoKolicina></NetoKolicina><JedinicaMjere></JedinicaMjere><MaloprodajnaCijena>2,00</MaloprodajnaCijena><Barkod></Barkod></Proizvod>
</Proizvodi>""".replace("{milk}", EAN_MILK).encode("utf-8")

METRO_CSV = konzum_csv([
    ["TEST Trajno mlijeko 2,8% m.m. 1 l", "M1", "TestDukat", "1", "l", "1.15", "1.15", "", "", "", EAN_MILK, "Mlijeko"],
])


def zip_of(files: dict[str, bytes]) -> bytes:
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for n, d in files.items():
            z.writestr(n, d)
    return b.getvalue()


class State:
    konzum_down = False
    date = "24.10.2026"


def make_routes():
    d = State.date
    kz_files = {
        f"SUPERMARKET,ULICA TEST 1 10290 ZAPREŠIĆ,0001,100001,{d}, 05-21.CSV": KZ_ZAP,
        f"SUPERMARKET,ISTOČNA ULICA 9 10000 ZAGREB,0002,100002,{d}, 05-21.CSV": KZ_ZG_EAST,
        f"SUPERMARKET,SAMOBORSKA 3 10430 SAMOBOR,0003,100003,{d}, 05-21.CSV": KZ_SAM,
        f"SUPERMARKET,RIVA 1 21000 SPLIT,0004,100004,{d}, 05-21.CSV": KZ_ZG_EAST,
    }
    lidl_zip = zip_of({
        f"Supermarket 101_Ulica Lidl_7_10290_Zaprešić_1_{d}_7.15h.csv": LIDL_ZAP,
        f"Supermarket 102_Ulica Split_1_21000_Split_1_{d}_7.15h.csv": LIDL_SPLIT,
    })
    stud_zip = zip_of({"Studenac_T100_PROIZVODI.xml": STUDENAC_XML})
    return kz_files, lidl_zip, stud_zip


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body: bytes, ctype="text/html; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        kz_files, lidl_zip, stud_zip = make_routes()
        if u.path == "/konzum/cjenici":
            if State.konzum_down:
                return self._send(503, b"down")
            page = int(q.get("page", ["1"])[0])
            if page > 1:
                return self._send(200, b"<html>nema</html>")
            links = "".join(f'<a href="/konzum/cjenici/download?title={quote(n)}">{n}</a>' for n in kz_files)
            return self._send(200, f"<html>{links}</html>".encode())
        if u.path == "/konzum/cjenici/download":
            n = q["title"][0]
            return self._send(200, kz_files[n], "text/csv")
        if u.path == "/lidl/cijene":
            return self._send(200, b'<a href="/lidl/files/Popis_cijena_po_trgovinama_na_dan_24_10_2026.zip">zip</a>'
                                   b'<a href="/lidl/files/Popis_cijena_po_trgovinama_na_dan_23_10_2026.zip">stari</a>')
        if u.path.startswith("/lidl/files/"):
            return self._send(200, lidl_zip, "application/zip")
        if u.path == "/studenac/":
            return self._send(200, b'<a href="/studenac/PROIZVODI-2026-10-24.zip">zip</a>')
        if u.path.startswith("/studenac/PROIZVODI"):
            return self._send(200, stud_zip, "application/zip")
        if u.path == "/metro/":
            return self._send(200, f'<a href="/metro/metro_{d_iso()}_s10_JANKOMIR 31,10090 ZAGREB.csv">j</a>'.encode())
        if u.path.startswith("/metro/metro_"):
            return self._send(200, METRO_CSV, "text/csv")
        if u.path == "/login-only/":
            return self._send(403, b"forbidden")
        return self._send(404, b"not found")


def d_iso():
    dd, mm, yy = State.date.split(".")
    return f"{yy}{mm}{dd}"


def start():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv
