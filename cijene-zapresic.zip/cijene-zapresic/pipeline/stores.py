"""Prodavaonice: identifikacija, geokodiranje (OpenStreetMap Nominatim, besplatno) i filtar radijusa."""
from __future__ import annotations

import hashlib
import json
import math
import re
import time
from pathlib import Path

from . import http
from .normalize import fold

NOMINATIM = "https://nominatim.openstreetmap.org/search"


def haversine_km(lat1, lon1, lat2, lon2) -> float:
    r = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def store_id(chain: str, meta: dict) -> str:
    key = meta.get("store_code") or ""
    basis = f"{chain}|{fold(meta.get('address'))}|{meta.get('postcode','')}|{key}"
    return f"{chain}-{hashlib.sha1(basis.encode()).hexdigest()[:10]}"


class Geocoder:
    """Geokodiranje adresa uz trajnu predmemoriju i ručne ispravke (config/stores_override.json)."""

    def __init__(self, cache_path: Path, overrides_path: Path, enabled: bool = True):
        self.cache_path = cache_path
        self.cache = json.loads(cache_path.read_text("utf-8")) if cache_path.exists() else {}
        self.overrides = json.loads(overrides_path.read_text("utf-8")) if overrides_path.exists() else {}
        self.enabled = enabled
        self._last = 0.0
        self.lookups = 0
        self.had_error = False

    def save(self):
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self.cache_path.write_text(json.dumps(self.cache, ensure_ascii=False, indent=0), "utf-8")

    def _query(self, q: str):
        if not self.enabled:
            return None
        wait = 1.1 - (time.time() - self._last)  # pravila korištenja Nominatima: najviše 1 upit/s
        if wait > 0:
            time.sleep(wait)
        self._last = time.time()
        self.lookups += 1
        try:
            res = http.get(NOMINATIM, params={"q": q, "format": "jsonv2", "limit": 1, "countrycodes": "hr"},
                           expect_json=True, tries=2)
        except Exception:
            self.had_error = True
            return None
        if res:
            return {"lat": float(res[0]["lat"]), "lon": float(res[0]["lon"]), "match": res[0].get("display_name", "")}
        return None

    def locate(self, sid: str, address: str, postcode: str, city: str) -> dict | None:
        """Vraća {'lat','lon','precision': 'adresa'|'rucno'} ili None ako adresa nije pouzdano pronađena."""
        if sid in self.overrides:
            o = self.overrides[sid]
            return {"lat": o["lat"], "lon": o["lon"], "precision": "ručno"}
        key = fold(f"{address}|{postcode}|{city}")
        if key in self.cache:
            return self.cache[key]
        self.had_error = False
        street = re.sub(r"(?i)\b(ul\.?|ulica)\b", "Ulica", address or "").strip()
        res = None
        if street:
            res = self._query(f"{street}, {postcode} {city}, Hrvatska")
            if not res:
                # bez kućnog broja (često 'BB' ili nestandardni zapis)
                s2 = re.sub(r"\s+(\d+\w?|bb)\s*$", "", street, flags=re.I)
                if s2 != street:
                    res = self._query(f"{s2}, {postcode} {city}, Hrvatska")
        out = {"lat": res["lat"], "lon": res["lon"], "precision": "adresa"} if res else None
        if out is None and self.enabled and not self.had_error:
            # adresa nije pronađena: središte mjesta (samo kao približna lokacija, vidi build.py)
            c = self._query(f"{postcode} {city}, Hrvatska") if (postcode or city) else None
            if c:
                out = {"lat": c["lat"], "lon": c["lon"], "precision": "mjesto"}
        if self.enabled and not self.had_error:
            self.cache[key] = out  # trajno pamti i neuspjeh, da se Nominatim ne opterećuje svaki dan
        return out
