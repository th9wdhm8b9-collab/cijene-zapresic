"""Normalizacija: tekst, cijene, EAN/GTIN, količine i jedinice mjere."""
from __future__ import annotations

import re
import unicodedata

# ---------------------------------------------------------------- tekst

def fold(s: str | None) -> str:
    """Mala slova, bez dijakritike, interpunkcija -> razmak, decimalni zarez -> točka."""
    if not s:
        return ""
    s = str(s).replace("đ", "dj").replace("Đ", "dj")
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    s = re.sub(r"(\d),(\d)", r"\1.\2", s)
    s = re.sub(r"[^a-z0-9%./]+", " ", s)
    s = re.sub(r"(?<!\d)\.|\.(?!\d)", " ", s)
    return re.sub(r"\s+", " ", s).strip()


# ---------------------------------------------------------------- cijene

def parse_price(v) -> float | None:
    """'1,29' / '1.29' / '1.234,56' / '1,29 €' -> 1.29 ; prazno/0/neispravno -> None."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v) if v > 0 else None
    s = str(v).strip().replace("€", "").replace("EUR", "").replace("\xa0", "").replace(" ", "")
    if not s:
        return None
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    else:
        s = s.replace(",", ".")
    try:
        f = float(s)
    except ValueError:
        return None
    if f <= 0 or f > 100000:
        return None
    return round(f, 4)


# ---------------------------------------------------------------- EAN / GTIN

def _gtin_ok(d: str) -> bool:
    total = 0
    for i, ch in enumerate(reversed(d[:-1])):
        total += int(ch) * (3 if i % 2 == 0 else 1)
    return (10 - total % 10) % 10 == int(d[-1])


def normalize_ean(v) -> str | None:
    """Vraća valjani globalni GTIN (8/13 znamenki) ili None.

    Interni kodovi trgovine (prefiks 02, 20-29 = ograničena distribucija, npr. vagani artikli)
    nisu globalni identifikator i ne smiju se koristiti za usporedbu među trgovcima.
    """
    if v is None:
        return None
    s = str(v).strip()
    if re.fullmatch(r"\d+\.0+", s):  # Excel artefakt '3850104000000.0'
        s = s.split(".")[0]
    s = re.sub(r"\s", "", s)
    if not s.isdigit():
        return None
    if len(s) == 14 and s.startswith("0"):
        s = s[1:]
    if len(s) == 12:
        s = "0" + s
    if len(s) not in (8, 13):
        return None
    if set(s) == {"0"} or not _gtin_ok(s):
        return None
    if len(s) == 13 and (s[0] == "2" or s.startswith("02")):
        return None
    return s


# ---------------------------------------------------------------- količine

UNIT_MAP = {
    "kg": ("kg", 1.0), "kilogram": ("kg", 1.0), "kgr": ("kg", 1.0),
    "g": ("kg", 0.001), "gr": ("kg", 0.001), "gram": ("kg", 0.001), "dag": ("kg", 0.01),
    "l": ("l", 1.0), "lit": ("l", 1.0), "litra": ("l", 1.0), "lt": ("l", 1.0), "ltr": ("l", 1.0),
    "ml": ("l", 0.001), "cl": ("l", 0.01), "dl": ("l", 0.1),
    "kom": ("kom", 1.0), "komad": ("kom", 1.0), "kos": ("kom", 1.0), "pak": ("kom", 1.0),
    "kut": ("kom", 1.0), "rol": ("kom", 1.0), "rola": ("kom", 1.0), "role": ("kom", 1.0),
    "kpl": ("kom", 1.0), "par": ("kom", 1.0), "pce": ("kom", 1.0), "pc": ("kom", 1.0), "pcs": ("kom", 1.0),
    "jaja": ("kom", 1.0), "tab": ("kom", 1.0),
    "pranje": ("pranje", 1.0), "pranja": ("pranje", 1.0), "wl": ("pranje", 1.0), "doza": ("pranje", 1.0),
}

_NUM = r"(\d+(?:\.\d+)?)"
_UNITS = r"(kg|kgr|g|gr|dag|ml|cl|dl|l|lit|ltr|lt|kom|kos|rola|role|rol|pranja|pranje|wl|tab)"
RE_MULTI = re.compile(rf"(?<![\d.])(\d+)\s*x\s*{_NUM}\s*{_UNITS}\b")
RE_SINGLE = re.compile(rf"(?<![\d.x]){_NUM}\s*{_UNITS}\b")
RE_SLASH = re.compile(r"(?<![\d.])(\d{1,3})\s*/\s*1\b")          # '10/1' (toaletni papir, jaja)
RE_WASH = re.compile(r"(?<![\d.])(\d{1,3})\s*(pranja|pranje|wl|doza)\b")


def unit_of(u) -> tuple[str, float] | None:
    if not u:
        return None
    k = fold(u).replace(" ", "").rstrip(".")
    return UNIT_MAP.get(k)


def parse_qty(qty_raw, unit_raw, name: str) -> dict:
    """Izračun neto količine u osnovnoj jedinici (kg / l / kom / pranje).

    Vraća dict: base, amount (ukupno u osnovnoj jedinici), count (broj komada u pakiranju),
    per_item (količina po komadu), washes (broj pranja ako je naveden), loose (vagani artikl),
    source ('polje' | 'naziv' | None).
    """
    out = {"base": None, "amount": None, "count": None, "per_item": None,
           "washes": None, "loose": False, "source": None}
    fname = fold(name)

    mw = re.search(r"(?<![\d.])(\d+)\s*x\s*(\d+)\s*(pranja|pranje|wl|doza)\b", fname)
    m = RE_WASH.search(fname)
    if mw:
        out["washes"] = int(mw.group(1)) * int(mw.group(2))
    elif m:
        out["washes"] = int(m.group(1))

    # 1) polja iz cjenika: neto količina + jedinica mjere
    q_txt = fold(qty_raw)
    u = unit_of(unit_raw)
    if q_txt:
        mm = RE_MULTI.search(q_txt)
        ms = RE_SINGLE.search(q_txt)
        if mm:
            un = unit_of(mm.group(3))
            if un:
                n, per = int(mm.group(1)), float(mm.group(2)) * un[1]
                out.update(base=un[0], amount=n * per, count=n, per_item=per, source="polje")
        elif ms:
            un = unit_of(ms.group(2))
            if un:
                out.update(base=un[0], amount=float(ms.group(1)) * un[1], source="polje")
        elif u and re.fullmatch(_NUM, q_txt):
            out.update(base=u[0], amount=float(q_txt) * u[1], source="polje")
        elif u and re.fullmatch(rf"(\d+)\s*x\s*{_NUM}", q_txt):
            mx = re.fullmatch(rf"(\d+)\s*x\s*{_NUM}", q_txt)
            n, per = int(mx.group(1)), float(mx.group(2)) * u[1]
            out.update(base=u[0], amount=n * per, count=n, per_item=per, source="polje")
    elif u and u[0] in ("kg", "l") and not RE_SINGLE.search(fname):
        # nema količine, jedinica je kg/l, a ni naziv ne navodi masu -> cijena je po kg/l (vagani artikl)
        out.update(base=u[0], amount=1.0, loose=True, source="polje")

    # 2) naziv proizvoda (ako polje nije dalo rezultat ili je samo '1 kom')
    if out["amount"] is None or (out["base"] == "kom" and out["amount"] == 1):
        mm = RE_MULTI.search(fname)
        ms = RE_SINGLE.search(fname)
        msl = RE_SLASH.search(fname)
        cand = None
        if mm and unit_of(mm.group(3)) and unit_of(mm.group(3))[0] != "pranje":
            un = unit_of(mm.group(3))
            n, per = int(mm.group(1)), float(mm.group(2)) * un[1]
            cand = dict(base=un[0], amount=n * per, count=n, per_item=per)
        elif ms and unit_of(ms.group(2)) and unit_of(ms.group(2))[0] != "pranje":
            un = unit_of(ms.group(2))
            cand = dict(base=un[0], amount=float(ms.group(1)) * un[1])
        if msl and int(msl.group(1)) > 1:
            n = int(msl.group(1))
            if cand is None or cand["base"] == "kom":
                cand = dict(base="kom", amount=float(n), count=n, per_item=1.0)
            else:
                cand.setdefault("count", n)
        if cand and (out["amount"] is None or cand["base"] != "kom" or cand["amount"] > 1):
            out.update(cand)
            out["source"] = "naziv"
    if out["amount"] is not None and out["amount"] <= 0:
        out.update(base=None, amount=None, source=None)
    if out["base"] == "kom" and out["count"] is None and out["amount"]:
        out["count"] = int(out["amount"]) if float(out["amount"]).is_integer() else None
    return out


def unit_label(base: str) -> str:
    return {"kg": "kg", "l": "l", "kom": "kom", "pranje": "pranje"}.get(base, base or "")


def check_unit_price(price: float | None, amount: float | None, stated: float | None) -> str | None:
    """Usporedba izračunate i u cjeniku navedene cijene po jedinici. Vraća upozorenje ili None."""
    if not price or not amount or not stated:
        return None
    calc = price / amount
    if stated <= 0:
        return None
    ratio = calc / stated
    if 0.9 <= ratio <= 1.1:
        return None
    return f"izračunata {calc:.2f} ≠ navedena {stated:.2f}"
