"""Glavni dnevni postupak: dohvat -> obrada -> filtar lokacije -> objedinjavanje -> objava podataka.

Pokretanje:  python -m pipeline.build [--out docs/data] [--state state] [--today YYYY-MM-DD]
"""
from __future__ import annotations

import argparse
import datetime as dt
import gzip
import hashlib
import json
import re
import sys
import time
import traceback
from collections import Counter, defaultdict
from pathlib import Path
from zoneinfo import ZoneInfo

from . import http
from .catalog import GROUPS, DEFAULT_ITEMS
from .normalize import fold, parse_price, normalize_ean, parse_qty, check_unit_price
from .parsing import parse_file, store_from_filename
from .sources import make_source
from .stores import Geocoder, haversine_km, store_id

ROOT = Path(__file__).resolve().parent.parent
MAX_STALE_DAYS = 30
SHARDS = 64


def log(*a):
    print(*a, file=sys.stderr, flush=True)


# ---------------------------------------------------------------- skupine

_compiled = []
for g in GROUPS:
    _compiled.append(dict(
        g,
        _all=[re.compile(p) for p in g.get("all", [])],
        _any=[re.compile(p) for p in g.get("any", [])],
        _excl=[re.compile(p) for p in g.get("excl", [])],
        _base=g["base"] if isinstance(g["base"], list) else [g["base"]],
    ))


def group_amount(g: dict, q: dict) -> float | None:
    """Količina proizvoda u osnovnoj jedinici skupine (npr. broj pranja kod deterdženta)."""
    if "pranje" in g["_base"]:
        if q.get("washes"):
            return float(q["washes"])
        if g.get("kom_kao_pranje") and q.get("base") == "kom" and q.get("amount"):
            return float(q["amount"])
        return None
    if q.get("base") in g["_base"]:
        return q.get("amount")
    return None


def match_groups(name: str, brand: str, q: dict) -> list[str]:
    text = fold(f"{name} {brand or ''}")
    out = []
    for g in _compiled:
        if not all(r.search(text) for r in g["_all"]):
            continue
        if g["_any"] and not any(r.search(text) for r in g["_any"]):
            continue
        if any(r.search(text) for r in g["_excl"]):
            continue
        amt = group_amount(g, q)
        if amt is None:
            continue
        lo, hi = g.get("amount") or [None, None]
        if lo is not None and not (lo * 0.999 <= amt <= hi * 1.001):
            continue
        if g.get("loose") and not q.get("loose"):
            continue
        out.append(g["id"])
    return out


# ---------------------------------------------------------------- dostupnost

def parse_avail(v):
    """Vraća (dostupno: True/False/None, količina_na_zalihi: float|None)."""
    if v is None:
        return None, None
    s = fold(v)
    if not s:
        return None, None
    if s in ("da", "d", "yes", "y", "true", "1", "dostupno", "dostupan", "na zalihi", "raspolozivo", "ima"):
        return True, None
    if s in ("ne", "n", "no", "false", "0", "nedostupno", "nije dostupno", "nema", "nema na zalihi", "rasprodano", "nedostupan"):
        return False, None
    return None, None


def parse_stock(v):
    s = str(v or "").strip().replace(",", ".")
    try:
        f = float(s)
    except ValueError:
        return None
    return f if f >= 0 else None


# ---------------------------------------------------------------- obrada jedne datoteke

def normalize_rows(chain: str, rows: list[dict]) -> tuple[list[dict], dict]:
    recs, stats = [], Counter()
    for r in rows:
        name = (r.get("name") or "").strip()
        price = parse_price(r.get("price"))
        special = parse_price(r.get("special"))
        if not name or (price is None and special is None):
            stats["preskočeno (bez naziva/cijene)"] += 1
            continue
        if price is None:
            price, special = special, None
        ean = normalize_ean(r.get("ean"))
        code = (r.get("code") or "").strip()
        brand = (r.get("brand") or "").strip()
        q = parse_qty(r.get("qty"), r.get("unit"), name)
        stated_up = parse_price(r.get("unit_price"))
        avail, stock = parse_avail(r.get("avail")) if "avail" in r else (None, None)
        if "stock_qty" in r:
            stock = parse_stock(r.get("stock_qty"))
            if stock is not None and avail is None:
                avail = stock > 0
        if special is not None and special >= price:
            special = None
        # navedena cijena po jedinici može se odnositi na redovnu ili akcijsku cijenu
        warn = None
        if q["amount"]:
            warn = check_unit_price(price, q["amount"], stated_up)
            if warn and special:
                warn = check_unit_price(special, q["amount"], stated_up)
        key = f"e:{ean}" if ean else f"c:{chain}:{code or hashlib.sha1(fold(name).encode()).hexdigest()[:12]}"
        recs.append(dict(k=key, n=name, b=brand, e=ean, c=code, q=q, p=price, s=special,
                         l30=parse_price(r.get("low30")), up=stated_up, a=avail, st=stock, w=warn,
                         cat=(r.get("category") or "").strip()))
        stats["artikala"] += 1
        stats["s EAN"] += bool(ean)
        stats["s količinom"] += q["amount"] is not None
        stats["s dostupnošću"] += avail is not None
    return recs, dict(stats)


# ---------------------------------------------------------------- glavni postupak

def run(settings_path: Path, out_dir: Path, state_dir: Path, today: dt.date | None = None,
        geocode: bool = True, chains_only: list[str] | None = None) -> dict:
    S = json.loads(settings_path.read_text("utf-8"))
    tz = ZoneInfo(S.get("timezone", "Europe/Zagreb"))
    now = dt.datetime.now(tz)
    today = today or now.date()
    http.configure(S["user_agent"], S.get("http_timeout_s", 60))
    center = S["center"]
    radius = S["radius_km"]
    prefixes = tuple(S.get("candidate_postcode_prefixes", []))
    geo = Geocoder(state_dir / "geocache.json", ROOT / "config" / "stores_override.json", enabled=geocode)
    state_dir.mkdir(parents=True, exist_ok=True)
    (state_dir / "stores").mkdir(exist_ok=True)

    coverage = {}
    stores: dict[str, dict] = {}          # sid -> meta
    store_recs: dict[str, list] = {}      # sid -> records (današnji)
    excluded = Counter()

    for chain, ccfg in S["chains"].items():
        if chains_only and chain not in chains_only:
            continue
        cov = coverage[chain] = dict(name=ccfg["name"], source=ccfg["url"], status="nepokriveno", files=0,
                                     stores_in_radius=0, stores_fresh=0, stores_stale=0, errors=[], notes=[],
                                     columns={}, stats=Counter())
        if ccfg.get("note"):
            cov["notes"].append(ccfg["note"])
        t0 = time.time()
        src = make_source(chain, ccfg)
        try:
            refs = src.discover(today)
        except Exception as e:
            cov["errors"].append(f"Izvor nedostupan: {e}")
            refs = []
        cov["notes"].extend(src.notes)
        exceptions = [x for x in S.get("always_include", []) if x["chain"] == chain]

        def wanted(meta: dict) -> bool:
            txt = fold(meta.get("raw", ""))
            if any(fold(m) in txt for x in exceptions for m in x["match"]):
                return True
            pc = meta.get("postcode")
            return (pc is None) or pc.startswith(prefixes)

        for ref in refs[: S.get("max_files_per_chain", 400)]:
            pre = store_from_filename(ref.name)
            if ref.name.lower().split("?")[0].endswith((".csv", ".xml")) and pre.get("postcode") and not wanted(pre):
                excluded["izvan šireg područja (poštanski broj)"] += 1
                continue
            try:
                data = http.get(ref.url).content
                parsed = parse_file(ref.name, data)
            except Exception as e:
                cov["errors"].append(f"{ref.name}: {e}")
                continue
            cov["files"] += 1
            for fname, rows, meta in parsed:
                sm = store_from_filename(fname)
                sm.update({k: v for k, v in (meta.get("store") or {}).items() if v and not sm.get(k)})
                if not wanted(sm):
                    excluded["izvan šireg područja (poštanski broj)"] += 1
                    continue
                exc = next((x for x in exceptions if any(fold(m) in fold(sm.get("raw", "")) for m in x["match"])), None)
                sid = store_id(chain, sm)
                if exc:
                    loc = {"lat": exc["lat"], "lon": exc["lon"], "precision": "ručno"}
                else:
                    loc = geo.locate(sid, sm.get("address", ""), sm.get("postcode", ""), sm.get("city", ""))
                if not loc:
                    excluded["lokacija nije utvrđena"] += 1
                    cov["notes"].append(f"Lokacija nije utvrđena: {fname}")
                    continue
                dist = haversine_km(center["lat"], center["lon"], loc["lat"], loc["lon"])
                # približna lokacija (središte mjesta): uključi samo ako je cijelo mjesto sigurno unutar radijusa
                margin = 3.0 if loc["precision"] == "mjesto" else 0.0
                in_radius = dist + margin <= radius
                if not in_radius and not exc:
                    excluded["izvan radijusa"] += 1
                    continue
                recs, st = normalize_rows(chain, rows)
                if not recs:
                    cov["errors"].append(f"{fname}: nema prepoznatljivih artikala (stupci: {meta.get('headers')})")
                    continue
                cov["columns"] = meta.get("columns", {})
                cov["stats"].update(st)
                stores[sid] = dict(
                    id=sid, chain=chain, chain_name=ccfg["name"], format=sm.get("format", ""),
                    address=(exc or {}).get("address") or sm.get("address", ""), postcode=sm.get("postcode", ""),
                    city=sm.get("city", ""), lat=round(loc["lat"], 6), lon=round(loc["lon"], 6),
                    loc_precision=loc["precision"], dist_km=round(dist, 2), in_radius=in_radius,
                    exception=(exc or {}).get("reason"), source_url=ref.url, source_file=fname,
                    file_date=sm.get("file_date") or ref.date, fetched_at=now.isoformat(timespec="seconds"),
                    last_ok_at=now.isoformat(timespec="seconds"), stale=False, columns=list(meta.get("columns", {}).keys()),
                )
                store_recs[sid] = recs
        cov["seconds"] = round(time.time() - t0, 1)
        log(f"[{chain}] datoteka={cov['files']} grešaka={len(cov['errors'])} ({cov['seconds']} s)")

    geo.save()

    # ---------------------------------------------- posljednji valjani podaci za trgovine koje danas nisu dohvaćene
    for f in (state_dir / "stores").glob("*.json.gz"):
        sid = f.name[:-8]
        if sid in stores:
            continue
        try:
            prev = json.loads(gzip.decompress(f.read_bytes()))
        except Exception:
            continue
        meta = prev["meta"]
        if chains_only and meta["chain"] not in chains_only:
            continue
        last = dt.datetime.fromisoformat(meta["last_ok_at"])
        age = (now - last).days
        if age > MAX_STALE_DAYS:
            continue
        meta.update(stale=True, stale_days=age, fetched_at=now.isoformat(timespec="seconds"))
        stores[sid] = meta
        store_recs[sid] = prev["recs"]

    for sid, meta in stores.items():
        if not meta.get("stale"):
            (state_dir / "stores" / f"{sid}.json.gz").write_bytes(
                gzip.compress(json.dumps({"meta": meta, "recs": store_recs[sid]}, ensure_ascii=False).encode()))
        # datoteka s jučerašnjim datumom = potencijalno zastarjelo
        if meta.get("file_date") and meta["file_date"] < today.isoformat():
            meta["old_file"] = True

    # ---------------------------------------------- pokrivenost po lancu
    for chain, cov in coverage.items():
        mine = [s for s in stores.values() if s["chain"] == chain]
        cov["stores_in_radius"] = len(mine)
        cov["stores_fresh"] = sum(1 for s in mine if not s.get("stale") and not s.get("old_file"))
        cov["stores_stale"] = len(mine) - cov["stores_fresh"]
        st = cov["stats"]
        n = st.get("artikala", 0) or 1
        cov["quality"] = {
            "artikala": st.get("artikala", 0),
            "udio_EAN": round(st.get("s EAN", 0) / n, 3),
            "udio_kolicina": round(st.get("s količinom", 0) / n, 3),
            "udio_dostupnost": round(st.get("s dostupnošću", 0) / n, 3),
        }
        cov["stats"] = dict(st)
        if cov["stores_fresh"] and not cov["errors"]:
            cov["status"] = "pokriveno"
        elif cov["stores_fresh"] or cov["stores_stale"]:
            cov["status"] = "djelomično"
        elif cov["errors"] or cov["files"] == 0:
            cov["status"] = "nepokriveno"
        else:
            cov["status"] = "nema prodavaonica u radijusu"
        cov["errors"] = cov["errors"][:30]
        cov["notes"] = list(dict.fromkeys(cov["notes"]))[:30]

    return publish(out_dir, stores, store_recs, coverage, dict(excluded), S, now, today)


# ---------------------------------------------------------------- objava

def shard_of(key: str) -> int:
    return int(hashlib.md5(key.encode()).hexdigest()[:6], 16) % SHARDS


def publish(out_dir: Path, stores, store_recs, coverage, excluded, S, now, today) -> dict:
    if not stores:
        # ništa nije dohvaćeno ni sačuvano: ne diraj postojeće objavljene podatke
        return dict(coverage=coverage, excluded=excluded, counts=dict(stores=0, products=0, with_ean=0))
    order = sorted(stores.values(), key=lambda s: (s["chain"], s["dist_km"]))
    idx = {s["id"]: i for i, s in enumerate(order)}
    products: dict[str, dict] = {}
    offers: dict[str, dict] = defaultdict(dict)  # key -> (tuple) -> [storeIdx]
    names: dict[str, Counter] = defaultdict(Counter)

    for sid, recs in store_recs.items():
        si = idx[sid]
        seen = set()
        for r in recs:
            k = r["k"]
            if k in seen:   # isti artikl dvaput u istoj datoteci: zadrži prvi
                continue
            seen.add(k)
            names[k][r["n"]] += 1
            p = products.get(k)
            if p is None:
                p = products[k] = dict(k=k, b=r["b"], e=r["e"], q=r["q"], cat=r["cat"], chains=set())
            elif p["q"]["amount"] is None and r["q"]["amount"] is not None:
                p["q"] = r["q"]
            if not p["b"] and r["b"]:
                p["b"] = r["b"]
            p["chains"].add(stores[sid]["chain"])
            t = (r["p"], r["s"], r["l30"], None if r["a"] is None else int(r["a"]), r["st"], r["up"], r["w"])
            offers[k].setdefault(t, []).append(si)

    group_members = defaultdict(list)
    shards = defaultdict(dict)
    search = []
    for k, p in products.items():
        p["n"] = names[k].most_common(1)[0][0]
        gids = match_groups(p["n"], p["b"], p["q"])
        for g in gids:
            group_members[g].append(k)
        o = [[t[0], t[1], t[2], t[3], t[4], t[5], t[6], sorted(v)] for t, v in offers[k].items()]
        o.sort(key=lambda x: x[1] or x[0])
        q = p["q"]
        rec = dict(n=p["n"], b=p["b"], e=p["e"], cat=p["cat"], g=gids,
                   q=[q["base"], q["amount"], q["count"], q["per_item"], q["washes"], int(q["loose"]), q["source"]],
                   o=o)
        sh = shard_of(k)
        shards[sh][k] = rec
        best = min((x[1] or x[0]) for x in o)
        search.append([k, p["n"], p["b"], q["base"], q["amount"], sh, sum(len(x[7]) for x in o), best])

    out_dir.mkdir(parents=True, exist_ok=True)
    pdir = out_dir / "p"
    pdir.mkdir(exist_ok=True)
    for f in pdir.glob("*.json"):
        f.unlink()
    for sh, recs in shards.items():
        (pdir / f"{sh}.json").write_text(json.dumps(recs, ensure_ascii=False, separators=(",", ":")), "utf-8")

    search.sort(key=lambda x: -x[6])
    (out_dir / "search.json").write_text(json.dumps(search, ensure_ascii=False, separators=(",", ":")), "utf-8")

    groups_out = []
    for g in GROUPS:
        mem = group_members.get(g["id"], [])
        groups_out.append(dict(id=g["id"], item=g["item"], label=g["label"], compare=g["compare"],
                               base=g["base"] if isinstance(g["base"], list) else [g["base"]],
                               kom_kao_pranje=bool(g.get("kom_kao_pranje")), alt=g.get("alt", []),
                               members=[[k, shard_of(k)] for k in mem]))
    # svi članovi skupina u jednoj datoteci -> početni zaslon učitava samo nju
    gp = {}
    for mem in group_members.values():
        for k in mem:
            gp[k] = shards[shard_of(k)][k]
    (out_dir / "gp.json").write_text(json.dumps(gp, ensure_ascii=False, separators=(",", ":")), "utf-8")
    (out_dir / "groups.json").write_text(json.dumps(dict(
        groups=groups_out,
        defaults=[dict(id=i, name=n, group=g, qty=q) for i, n, g, q in DEFAULT_ITEMS],
    ), ensure_ascii=False, separators=(",", ":")), "utf-8")

    meta = dict(
        generated_at=now.isoformat(timespec="seconds"),
        data_date=today.isoformat(),
        center=S["center"], radius_km=S["radius_km"],
        stores=order,
        coverage=coverage,
        excluded=excluded,
        counts=dict(stores=len(order), products=len(products),
                    with_ean=sum(1 for p in products.values() if p["e"])),
        shards=SHARDS,
    )
    (out_dir / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, separators=(",", ":"), default=list), "utf-8")
    log(f"Objavljeno: {len(order)} prodavaonica, {len(products)} artikala -> {out_dir}")
    return meta


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--settings", default=str(ROOT / "config" / "settings.json"))
    ap.add_argument("--out", default=str(ROOT / "docs" / "data"))
    ap.add_argument("--state", default=str(ROOT / "state"))
    ap.add_argument("--today")
    ap.add_argument("--no-geocode", action="store_true")
    ap.add_argument("--chains", nargs="*")
    a = ap.parse_args(argv)
    today = dt.date.fromisoformat(a.today) if a.today else None
    try:
        meta = run(Path(a.settings), Path(a.out), Path(a.state), today, geocode=not a.no_geocode, chains_only=a.chains)
    except Exception:
        traceback.print_exc()
        return 2
    ok = sum(1 for c in meta["coverage"].values() if c["status"] in ("pokriveno", "djelomično"))
    log(f"Lanaca s podacima: {ok}/{len(meta['coverage'])}")
    if meta["counts"]["stores"] == 0:
        log("UPOZORENJE: nema nijedne prodavaonice s podacima – objava se preskače da se ne izbrišu postojeći podaci.")
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
