"""Kratki izvještaj o pokrivenosti (Markdown) – za GitHub sažetak ili ručnu provjeru."""
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main(path=ROOT / "docs" / "data" / "meta.json"):
    if not Path(path).exists():
        print("Nema meta.json – podaci nisu objavljeni.")
        return
    m = json.loads(Path(path).read_text("utf-8"))
    print(f"## Cijene Zaprešić – {m['generated_at']}\n")
    print(f"{m['counts']['stores']} poslovnica, {m['counts']['products']} artikala ({m['counts']['with_ean']} s EAN-om).\n")
    print("| Lanac | Status | Poslovnica (aktualno/starije) | Datoteka | EAN | Količina | Dostupnost | Greške |")
    print("|---|---|---|---|---|---|---|---|")
    for c in m["coverage"].values():
        q = c.get("quality", {})
        print(f"| {c['name']} | {c['status']} | {c['stores_in_radius']} ({c['stores_fresh']}/{c['stores_stale']}) | {c['files']} | "
              f"{q.get('udio_EAN', 0):.0%} | {q.get('udio_kolicina', 0):.0%} | {q.get('udio_dostupnost', 0):.0%} | {len(c['errors'])} |")
    print()
    for c in m["coverage"].values():
        for e in c["errors"][:5] + c["notes"][:5]:
            print(f"- **{c['name']}**: {e}")
    print("\n### Broj artikala po skupini (provjera prepoznavanja)\n")
    g = json.loads((Path(path).parent / "groups.json").read_text("utf-8"))
    for x in g["groups"]:
        print(f"- {x['label']}: {len(x['members'])}")


if __name__ == "__main__":
    main(*sys.argv[1:])
