"""Čitanje službenih cjenika: CSV, XML i ZIP (s CSV/XML unutra).

Stupci se prepoznaju po nazivima zaglavlja (ključne riječi), jer svaki lanac koristi
vlastite nazive i redoslijed stupaca. Sve što se ne može pouzdano prepoznati ostaje prazno.
"""
from __future__ import annotations

import csv
import io
import re
import zipfile
import xml.etree.ElementTree as ET

from .normalize import fold

# Redoslijed je bitan: specifičnija pravila prije općenitih.
# (polje, [obvezne riječi], [zabranjene riječi])
HEADER_RULES = [
    ("low30",      ["najniz"], []),
    ("anchor",     ["sidren"], []),
    ("special",    ["posebn"], []),
    ("special",    ["akcij"], ["naziv", "oznak"]),
    ("special_name", ["naziv", "akcij"], []),
    ("unit_price", ["jedinic", "cijen"], []),
    ("unit_price", ["cijena", "mjer"], []),
    ("unit_price", ["cijena", "jm"], []),
    ("unit_price", ["cijena", "kg"], []),
    ("stock_qty",  ["kolicin", "zalih"], []),
    ("stock_qty",  ["stanje"], []),
    ("avail",      ["dostupn"], []),
    ("avail",      ["raspoloziv"], []),
    ("avail",      ["zalih"], []),
    ("price",      ["maloprodajn"], []),
    ("price",      ["mpc"], []),
    ("price",      ["cijena"], []),
    ("ean",        ["barkod"], []),
    ("ean",        ["bar", "kod"], []),
    ("ean",        ["ean"], []),
    ("ean",        ["gtin"], []),
    ("unit",       ["jedinic", "mjer"], []),
    ("unit",       ["jm"], []),
    ("qty",        ["neto", "kolicin"], []),
    ("qty",        ["kolicin"], []),
    ("qty",        ["gramaz"], []),
    ("name",       ["naziv", "proizvod"], []),
    ("name",       ["naziv", "artikl"], []),
    ("name",       ["naziv"], ["kategorij", "trgovin", "marke", "brand"]),
    ("name",       ["opis"], []),
    ("code",       ["sifr"], []),
    ("code",       ["artikl", "broj"], []),
    ("brand",      ["marka"], []),
    ("brand",      ["marke"], []),
    ("brand",      ["brand"], []),
    ("brand",      ["proizvodjac"], []),
    ("category",   ["kategorij"], []),
    ("category",   ["grupa"], []),
]


def map_headers(headers: list[str]) -> dict[str, int]:
    mapping: dict[str, int] = {}
    folded = [fold(h).replace(" ", "_") for h in headers]
    for field, need, forbid in HEADER_RULES:
        if field in mapping:
            continue
        for i, h in enumerate(folded):
            if i in mapping.values():
                continue
            if all(w in h for w in need) and not any(w in h for w in forbid):
                mapping[field] = i
                break
    return mapping


def _decode(data: bytes) -> str:
    for enc in ("utf-8-sig", "cp1250", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def parse_csv(data: bytes) -> tuple[list[dict], dict]:
    text = _decode(data)
    sample = text[:20000]
    first = sample.splitlines()[0] if sample else ""
    counts = {d: first.count(d) for d in (";", ",", "\t", "|")}
    delim = max(counts, key=counts.get)
    reader = csv.reader(io.StringIO(text), delimiter=delim)
    rows = list(reader)
    if not rows:
        return [], {"columns": {}, "headers": []}
    # zaglavlje = prvi redak koji sadrži nešto kao 'naziv'/'cijena'
    hi = 0
    for i, r in enumerate(rows[:10]):
        f = fold(" ".join(r))
        if ("naziv" in f or "opis" in f) and ("cijen" in f or "mpc" in f):
            hi = i
            break
    headers = rows[hi]
    m = map_headers(headers)
    out = []
    for r in rows[hi + 1:]:
        if not any(c.strip() for c in r):
            continue
        rec = {f: (r[i].strip() if i < len(r) else "") for f, i in m.items()}
        out.append(rec)
    return out, {"columns": {k: headers[v] for k, v in m.items()}, "headers": headers, "delimiter": delim}


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def parse_xml(data: bytes) -> tuple[list[dict], dict]:
    root = ET.fromstring(data)
    # pronađi element koji se najčešće ponavlja s djecom = proizvod
    counts: dict[str, int] = {}
    for el in root.iter():
        if len(el):
            counts[_local(el.tag)] = counts.get(_local(el.tag), 0) + 1
    if not counts:
        return [], {"columns": {}, "headers": []}
    item_tag = max(counts, key=counts.get)
    items = [el for el in root.iter() if _local(el.tag) == item_tag]
    headers: list[str] = []
    for el in items[:50]:
        for ch in el:
            t = _local(ch.tag)
            if t not in headers:
                headers.append(t)
        for a in el.attrib:
            if a not in headers:
                headers.append(a)
    m = map_headers(headers)
    out = []
    for el in items:
        vals = {_local(ch.tag): (ch.text or "").strip() for ch in el}
        vals.update(el.attrib)
        out.append({f: vals.get(headers[i], "") for f, i in m.items()})
    # podaci o prodavaonici unutar XML-a (ako postoje)
    store = {}
    for el in root.iter():
        t = fold(_local(el.tag))
        if not len(el) and el.text and el.text.strip():
            if "adres" in t and "address" not in store:
                store["address"] = el.text.strip()
            elif ("grad" in t or "mjesto" in t) and "city" not in store:
                store["city"] = el.text.strip()
            elif ("postansk" in t or "zip" in t) and "postcode" not in store:
                store["postcode"] = el.text.strip()
    return out, {"columns": {k: headers[v] for k, v in m.items()}, "headers": headers, "store": store}


def parse_file(name: str, data: bytes) -> list[tuple[str, list[dict], dict]]:
    """Vraća listu (naziv_datoteke, retci, meta). ZIP se raspakira."""
    low = name.lower()
    if data[:2] == b"PK" or low.endswith(".zip"):
        res = []
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for info in z.infolist():
                if info.is_dir():
                    continue
                inner = info.filename
                # dekodiranje naziva datoteke s hrvatskim znakovima (cp437 -> cp1250/utf-8)
                if not (info.flag_bits & 0x800):
                    raw = inner.encode("cp437", errors="ignore")
                    for enc in ("utf-8", "cp1250"):
                        try:
                            inner = raw.decode(enc)
                            break
                        except UnicodeDecodeError:
                            pass
                res.extend(parse_file(inner, z.read(info)))
        return res
    head = data.lstrip()[:200]
    if low.endswith(".xml") or head.startswith(b"<?xml") or head.startswith(b"<"):
        rows, meta = parse_xml(data)
    else:
        rows, meta = parse_csv(data)
    return [(name, rows, meta)]


# ---------------------------------------------------------------- podaci o prodavaonici iz naziva datoteke

RE_POSTCODE = re.compile(r"(?<!\d)([1-5]\d{4})(?!\d)")
RE_DATE = re.compile(r"(\d{1,2})[._-](\d{1,2})[._-](20\d{2})|(20\d{2})[._-]?(\d{2})[._-]?(\d{2})")


def store_from_filename(fname: str) -> dict:
    """Iz naziva datoteke izvlači adresu, poštanski broj, mjesto, oznaku prodavaonice i datum.

    Primjeri:
      'SUPERMARKET,ŽITNA 1A 10310 IVANIĆ GRAD,0204,102513,24.10.2026, 05-21.CSV'
      'Supermarket 265_Ulica Franje Glada_13_40323_Prelog_1_24.10.2026_7.15h.csv'
    """
    base = fname.rsplit("/", 1)[-1]
    base = re.sub(r"\.(csv|xml|txt)$", "", base, flags=re.I)
    d = {"raw": base}
    md = RE_DATE.search(base)
    if md:
        if md.group(3):
            d["file_date"] = f"{md.group(3)}-{int(md.group(2)):02d}-{int(md.group(1)):02d}"
        else:
            d["file_date"] = f"{md.group(4)}-{md.group(5)}-{md.group(6)}"
        base_nodate = base[:md.start()] + " " + base[md.end():]
    else:
        base_nodate = base
    tokens = [t for t in re.split(r"[,_;]+", base_nodate) if t.strip()]
    mp = None
    for m in RE_POSTCODE.finditer(base_nodate):
        mp = m
        break
    if mp:
        d["postcode"] = mp.group(1)
        before = base_nodate[:mp.start()]
        after = base_nodate[mp.end():]
        city = re.split(r"[,_;]", after.strip(" ,_;-"))[0].strip()
        city = re.sub(r"\s+\d.*$", "", city)
        d["city"] = city.title() if city else ""
        parts = [p.strip() for p in re.split(r"[,_;]", before) if p.strip()]
        # format tipa 'SUPERMARKET' / 'Supermarket 265' na početku
        if parts and re.match(r"(?i)^(hipermarket|supermarket|market|trgovina|prodavaonica|diskont|cash|maxi|super|mini|extra|express|studenac|interspar|spar)\b", parts[0]):
            d["format"] = parts[0]
            parts = parts[1:]
        d["address"] = " ".join(parts).strip().title()
    codes = [t.strip() for t in tokens if re.fullmatch(r"\s*[A-Za-z]?\d{2,6}\s*", t) and t.strip() != d.get("postcode")]
    if codes:
        d["store_code"] = codes[0]
    return d
