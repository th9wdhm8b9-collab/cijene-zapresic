"""HTTP dohvat s ponovnim pokušajima. Samo javni GET zahtjevi, bez prijave i zaobilaženja ograničenja."""
from __future__ import annotations

import time
import requests

_session: requests.Session | None = None
_settings = {"ua": "CijeneZapresic/1.0", "timeout": 60}


def configure(user_agent: str, timeout: int):
    _settings.update(ua=user_agent, timeout=timeout)


def session() -> requests.Session:
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update({
            "User-Agent": _settings["ua"],
            "Accept-Language": "hr-HR,hr;q=0.9,en;q=0.5",
        })
    return _session


class FetchError(Exception):
    pass


def get(url: str, *, params=None, tries: int = 3, expect_json: bool = False):
    last = None
    for attempt in range(tries):
        try:
            r = session().get(url, params=params, timeout=_settings["timeout"])
            if r.status_code in (401, 403):
                raise FetchError(f"HTTP {r.status_code} – izvor zahtijeva prijavu ili je pristup odbijen")
            if r.status_code == 404:
                raise FetchError("HTTP 404 – datoteka/stranica ne postoji")
            r.raise_for_status()
            return r.json() if expect_json else r
        except FetchError:
            raise
        except Exception as e:  # mreža, timeout, 5xx
            last = e
            time.sleep(2 * (attempt + 1))
    raise FetchError(f"{type(last).__name__}: {last}")
