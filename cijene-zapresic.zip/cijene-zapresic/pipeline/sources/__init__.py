"""Moduli izvora cjenika. Novi trgovac = novi modul + zapis u config/settings.json."""
from __future__ import annotations

import datetime as dt
import json
import re
from urllib.parse import quote

from .. import http
from .base import Source, FileRef, extract_file_links, pick_latest, date_in, name_from_url


class GenericSource(Source):
    """Pretražuje službenu stranicu za poveznice na CSV/XML/ZIP datoteke."""


class KonzumSource(Source):
    """konzum.hr/cjenici?date=YYYY-MM-DD&page=N – jedna CSV datoteka po prodavaonici (provjereno)."""

    def discover(self, today):
        base = self.cfg["url"]
        for back in range(0, 4):
            day = today - dt.timedelta(days=back)
            refs, seen = [], set()
            for page in range(1, 60):
                html = http.get(base, params={"date": day.isoformat(), "page": page}).text
                new = [r for r in extract_file_links(html, base) if r.url not in seen]
                if not new:
                    break
                for r in new:
                    seen.add(r.url)
                    r.date = r.date or day.isoformat()
                refs.extend(new)
            if refs:
                if back:
                    self.notes.append(f"Za danas još nema cjenika; korišten je cjenik od {day.isoformat()}.")
                return refs
        self.notes.append("Nema objavljenih cjenika u zadnja 4 dana.")
        return []


class KauflandSource(Source):
    """Kaufland objavljuje popis datoteka kao JSON (assetSearch) na stranici popisa MPC."""

    def discover(self, today):
        url = self.cfg["url"]
        html = http.get(url).text
        refs = extract_file_links(html, url)
        m = re.search(r"""["']([^"']*assetSearch[^"']*\.json)["']""", html)
        if m:
            from urllib.parse import urljoin
            try:
                data = http.get(urljoin(url, m.group(1)), expect_json=True)
                items = data if isinstance(data, list) else data.get("assets") or data.get("items") or []
                for it in items:
                    p = it.get("path") or it.get("url") or it.get("href")
                    if not p:
                        continue
                    u = urljoin(url, p)
                    nm = it.get("label") or it.get("filename") or name_from_url(u)
                    refs.append(FileRef(url=u, name=nm, date=date_in(nm) or date_in(u)))
            except Exception as e:  # noqa
                self.notes.append(f"JSON popis datoteka nije dohvaćen: {e}")
        latest, d = pick_latest(refs, today)
        if not refs:
            self.notes.append("Poveznice na cjenike nisu pronađene.")
        return latest


class SparSource(Source):
    """SPAR/INTERSPAR: dnevni JSON popis datoteka (datoteke_cjenici/CjenikYYYYMMDD.json), uz rezervu – stranica."""

    def discover(self, today):
        for back in range(0, 4):
            day = today - dt.timedelta(days=back)
            u = f"https://www.spar.hr/datoteke_cjenici/Cjenik{day.strftime('%Y%m%d')}.json"
            try:
                data = http.get(u, expect_json=True, tries=1)
            except Exception:
                continue
            files = data.get("files", []) if isinstance(data, dict) else data
            refs = []
            for f in files:
                fu = f.get("URL") or f.get("url")
                if fu:
                    nm = f.get("name") or name_from_url(fu)
                    refs.append(FileRef(url=fu, name=nm, date=date_in(nm) or day.isoformat()))
            if refs:
                if back:
                    self.notes.append(f"Korišten JSON popis od {day.isoformat()}.")
                return refs
        self.notes.append("JSON popis nije dostupan – pretražujem stranicu.")
        return super().discover(today)


class TommySource(Source):
    """Tommy: pokušava javni popis cjenika s web trgovine, a zatim službenu stranicu."""

    def discover(self, today):
        api = "https://spiza.tommy.hr/api/v2/shop/store-prices-tables"
        refs = []
        try:
            for page in range(1, 20):
                data = http.get(api, params={"date": today.isoformat(), "page": page, "itemsPerPage": 200},
                                expect_json=True, tries=1)
                members = data.get("hydra:member") or data.get("member") or []
                if not members:
                    break
                for it in members:
                    for k, v in it.items():
                        if isinstance(v, str) and re.search(r"\.csv|/csv", v, re.I):
                            u = v if v.startswith("http") else "https://spiza.tommy.hr" + v
                            nm = it.get("fileName") or it.get("label") or name_from_url(u)
                            refs.append(FileRef(url=u, name=nm, date=today.isoformat()))
        except Exception as e:  # noqa
            self.notes.append(f"API popis nije dostupan ({e}); pretražujem stranicu.")
        return refs or super().discover(today)


MODULES = {
    "generic": GenericSource,
    "konzum": KonzumSource,
    "kaufland": KauflandSource,
    "spar": SparSource,
    "tommy": TommySource,
}


def make_source(chain_id: str, cfg: dict) -> Source:
    return MODULES.get(cfg.get("module", "generic"), GenericSource)(chain_id, cfg)
