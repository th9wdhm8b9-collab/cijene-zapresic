"""Zajednička logika za pronalazak datoteka cjenika na službenim stranicama trgovaca."""
from __future__ import annotations

import datetime as dt
import html
import re
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlparse, unquote, parse_qs

from .. import http

RE_FILE_URL = re.compile(
    r"""(?:href|src|value|data-[a-z-]+|url|path|link)\s*[=:]\s*["']([^"'<>]+?\.(?:csv|xml|zip)(?:\?[^"'<>]*)?)["']"""
    r"""|["'](https?://[^"'<>\s]+?\.(?:csv|xml|zip)(?:\?[^"'<>]*)?)["']""",
    re.I,
)
RE_DOWNLOAD_URL = re.compile(r"""href\s*=\s*["']([^"']*(?:download|preuzmi)[^"']*\.(?:csv|xml|zip)[^"']*)["']""", re.I)
RE_ANY_HREF = re.compile(r"""href\s*=\s*["']([^"'#]+)["']""", re.I)
RE_DATE_ANY = re.compile(
    r"(?<!\d)(\d{1,2})[._-](\d{1,2})[._-](20\d{2})(?!\d)|(?<!\d)(20\d{2})[._-](\d{1,2})[._-](\d{1,2})(?!\d)|(?<!\d)(20\d{2})(\d{2})(\d{2})(?!\d)"
)


@dataclass
class FileRef:
    url: str
    name: str
    date: str | None = None          # YYYY-MM-DD ako se može odrediti iz naziva/URL-a
    extra: dict = field(default_factory=dict)


def date_in(text: str) -> str | None:
    for m in RE_DATE_ANY.finditer(unquote(text)):
        try:
            if m.group(3):
                d = dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            elif m.group(4):
                d = dt.date(int(m.group(4)), int(m.group(5)), int(m.group(6)))
            else:
                d = dt.date(int(m.group(7)), int(m.group(8)), int(m.group(9)))
        except ValueError:
            continue
        if 2024 <= d.year <= 2100:
            return d.isoformat()
    return None


def name_from_url(url: str) -> str:
    q = parse_qs(urlparse(url).query)
    for k in ("title", "file", "filename", "name"):
        if k in q:
            return unquote(q[k][0])
    return unquote(urlparse(url).path.rsplit("/", 1)[-1])


def extract_file_links(page_html: str, base_url: str) -> list[FileRef]:
    text = html.unescape(page_html)
    seen, out = set(), []
    for rx in (RE_FILE_URL, RE_DOWNLOAD_URL):
        for m in rx.finditer(text):
            raw = next(g for g in m.groups() if g)
            url = urljoin(base_url, raw.strip())
            if url in seen:
                continue
            seen.add(url)
            nm = name_from_url(url)
            out.append(FileRef(url=url, name=nm, date=date_in(nm) or date_in(url)))
    return out


def pick_latest(refs: list[FileRef], today: dt.date) -> tuple[list[FileRef], str | None]:
    """Datoteke s najnovijim datumom koji nije u budućnosti. Ako datuma nema, vraća sve."""
    dated = [r for r in refs if r.date and r.date <= today.isoformat()]
    if not dated:
        return refs, None
    latest = max(r.date for r in dated)
    return [r for r in dated if r.date == latest], latest


class Source:
    """Osnovni modul izvora. Svaki lanac može nadjačati discover()."""

    def __init__(self, chain_id: str, cfg: dict):
        self.chain_id = chain_id
        self.cfg = cfg
        self.notes: list[str] = []

    def discover(self, today: dt.date) -> list[FileRef]:
        url = self.cfg["url"]
        page = http.get(url).text
        refs = extract_file_links(page, url)
        if not refs and self.cfg.get("follow_subpages"):
            refs = self._follow(page, url)
        if not refs:
            self.notes.append("Na službenoj stranici nisu pronađene poveznice na CSV/XML/ZIP datoteke.")
        latest, d = pick_latest(refs, today)
        if d and d < today.isoformat():
            self.notes.append(f"Najnoviji objavljeni cjenik je od {d} (ne današnji).")
        return latest

    def _follow(self, page: str, url: str, limit: int = 300) -> list[FileRef]:
        host = urlparse(url).netloc
        subs = []
        for m in RE_ANY_HREF.finditer(html.unescape(page)):
            u = urljoin(url, m.group(1))
            if urlparse(u).netloc == host and re.search(r"cjeni|cijen|poslovnic|objekt|trgovin", u, re.I) and u != url:
                if u not in subs:
                    subs.append(u)
        refs: list[FileRef] = []
        for u in subs[:limit]:
            try:
                refs.extend(extract_file_links(http.get(u).text, u))
            except http.FetchError as e:
                self.notes.append(f"Podstranica nedostupna: {u} ({e})")
        uniq = {r.url: r for r in refs}
        return list(uniq.values())
