"""Početni katalog (≈20 proizvoda) i skupine usporedivih artikala.

Svaka skupina (varijanta) opisuje USPOREDIVE proizvode – istu vrstu, sličan sastav i sličnu
veličinu pakiranja. Različite vrste (npr. gauda i svježi sir) nikad nisu u istoj skupini.

Pravila se primjenjuju na naziv + marku, pretvorene u mala slova bez dijakritike
(npr. 'Trajno mlijeko 2,8% m.m.' -> 'trajno mlijeko 2.8% m m').

  all      – svi izrazi moraju se pojaviti
  any      – barem jedan (ako je naveden)
  excl     – nijedan se ne smije pojaviti
  base     – osnovna jedinica: kg | l | kom | pranje (više dopuštenih: lista)
  amount   – [min, max] ukupne količine u osnovnoj jedinici (None = bez ograničenja)
  compare  – 'ean'  : uspoređuje se ISTI artikl (EAN) među trgovinama; ostali članovi = pametne alternative
             'opis' : artikli bez EAN-a (rasuto voće, povrće, meso, pekara) – usporedba prema opisu,
                      u aplikaciji označena kao nesigurna
  kom_kao_pranje – broj komada (kapsula) se koristi kao broj pranja
  alt      – srodne skupine iste vrste (npr. veće pakiranje) koje se smiju ponuditi kao pametna alternativa
"""

MILK_X = (r"cokol|kakao|\bkav|jogurt|kefir|kozj|ovcj|biljn|\bsoj|\bzob|kokos|\briz|badem|kondenz|prah|napitak|"
          r"sapun|losion|krem|tijel|\bgel\b|sampon|keks|vanil|jagod|banan|desert|puding|sladoled|frape|cappuc|latte|"
          r"\bsir\b|vrhnj|maslac|\bcaj|dojenc|formul|pocetn|nastavn|shake|protein|ukus|okus|lesnj|ljesnj|kozmet")
YOG_X = (r"\bvoc|jagod|banan|breskv|visnj|borovn|malin|vanil|cokol|kakao|musli|zitar|grck|skyr|kefir|\bab\b|bifid|probiot|"
         r"actimel|protein|laktoz|biljn|\bsoj|kokos|\bzob|napitak|sladoled|dresing|umak|preljev|keks|smoothie|kozj|ovcj|"
         r"okus|stracciat|limun|kava|marelic|sumsk|tropic|ananas|kruska|jabuk|sljiv|med\b|lesnj|ljesnj|desert")
EGG_X = r"cokol|kinder|bombon|liker|tjesten|jajn|rezanc|noodle|majonez|pasta|cupav|surprise|igrack|kalup|kuhal|\bboj|uskrs|zecic|prepelic|keks|pecivo"
BUTTER_X = r"biljn|margarin|kikirik|kakao|lesnj|ljesnj|badem|shea|kokos|tijel|krem|namaz|maslac od|keks|kroasan|croissant|pecivo|cokol|kolac|\btost|kikiriki|ghee|ruz|usn"
CHEESE_X = r"narez|listic|ploc|slices|ribani|topljen|dimlj|grick|stick|kocki|sendvic|pecivo|burek|pizza|lazanj|kreker|chips|cips|pita|strukl|tortelin|ravioli|umak|namaz|krem"
BREAD_X = r"\btost|mrvic|prezl|kreker|pecivo|smrz|zamrz|kruhov|kruh od|pogac|grisin|dvopek|sendvic|toster|brasno|smjesa|mix za|krutoni|chips|cips"
FLOUR_X = r"kukuruz|\bzob|\braz|\bpir|heljd|rizin|badem|kokos|integral|gluten|pecivo|smjes|pizza|palacink|kolac|uskrs|krupic|griz|instant|mix|biskvit|tortilj|kruh"
SUGAR_X = r"vanil|smedj|\bprah|kock|trsk|kokos|bez secer|bezsec|sirup|slatkis|zamjen|stevi|eritrit|ksilit|grozd|dekor|bombon|zele|limunad|stapic|stick|\bmed\b|bijeli kruh|cokol|keks|sok|napitak|kolac"
OIL_X = r"maslin|repic|bucin|kokos|lanen|sezam|orah|tun|sardin|ribe|riba|u (\w+ )?ulju|majonez|cips|chips|krem|sprej|spray|kozmet|tijel|masaz|grick|svijec|repicin|mjesavin|blend|\bmix|dezodor"
RICE_X = r"rizin|mlijek|napitak|kreker|vafl|kolac|puding|ocat|brasn|pahuljic|cips|chips|krisp|crisp|galet|\bkuhana|gotov|salat|obrok|\bmix|mjesav|sa povrc|s povrc|tortilj|rezanc|noodle|papir|sake|ulje"
POTATO_X = r"pomfr|cips|chips|pire|slatk|batat|njok|kroket|pecen|salat|smrz|zamrz|prilog|wedges|rosti|juha|kase|grick|stick|pecivo|kruh|brasn|skrob|pahuljic|\bmix|smjes|kolac|frites"
ONION_X = r"cesnj|mlad|proljet|ljutik|przen|przen|kosir|vlasac|\bsol\b|granul|prah|zacin|umak|krem|namaz|cips|chips|grick|pecivo|kreker|pizza|\bsir\b|pastet|kobas|salam|marinad|dresing|kapuljac|juha|krumpir|ulje|kolut|sirup|cvjet|lukovic|\bcesn"
BANANA_X = r"cips|chips|susen|jogurt|\bsok\b|smoothie|kasic|kasa|puding|napitak|mlijek|cokol|bombon|keks|sladoled|pire|bebe|hipp|frutek|vocn|musli|kolac|liker|kakao|\bmix|ploc|\bbar\b|protein|zele|aroma|kruh"
APPLE_X = (r"\bsok\b|nektar|kasic|kasa|ocat|cips|chips|susen|\bpita|strudl|struk|jogurt|cider|pire|smoothie|napitak|\bcaj|kolac|keks|sladoled|"
           r"pecivo|musli|bombon|\bmix|vocn|marmelad|dzem|pekmez|kompot|liker|rakij|hipp|frutek|bebe|ploc|\bbar\b|zele|sirup|aroma|osvjez|"
           r"kozmet|sampon|\bgel\b|tijel|cimet|koncentr|limunad|kruska")
CHICKEN_X = (r"pohan|dimlj|narez|sunk|kuhan|nugget|medaljon|hrenov|kobas|salam|pastet|pecen|grill|gotov|sendvic|juha|temeljac|\bkock|pizza|"
             r"tortilj|wrap|salat|batak|krilc|zabatak|\bpur|kroket|cordon|smrz|zamrz|ljut|marinir|bbq|kebab|gyros|stick|hot ?dog|lovack|"
             r"zacin|mjesavin|zdenk|hrana za|pas\b|mack|whiskas|felix|friskies|pedigree|chappi|purina|vrecic|konzerv|ribic|cips|chips")
MINCE_X = (r"pljesk|cevap|burger|cuft|polpet|sarm|punjen|lasagn|lazanj|umak|bolonj|gotov|smrz|zamrz|\bkav|papar|zacin|\bmak\b|orah|kobas|"
           r"pastet|paprik|bademi|ljesnj|lesnj|kikiriki|hrana za|mack|\bpas\b|cokol|keks|sol\b|pikant")
PASTA_X = r"umak|gotov|bolonj|carbonar|juha|integral|pirov|gluten|kukuruz|rizin|\bzob|heljd|konzerv|ready|\bkit\b|\bset\b|obrok|svjez|punjen|salat|crna|\bjaj"
COFFEE_X = (r"kapsul|kapsl|\bcaps|jastuc|\bpad|instant|topiv|3 ?u ?1|2 ?u ?1|cappuc|latte|leden|napitak|liker|cokol|keks|bombon|krem|aparat|"
            r"filter ?papir|soljic|salic|kafetijer|mlin|\bzrn|cigoric|zitn|ostar|mocca ?mix|frape|kvas|kolac|torta|sladoled|jogurt")
TP_X = r"vlazn|marami|kuhinj|rucnik|drzac|stalak|wc ?gel|osvjez|cistac|daska|cetk|blok|ubrus"
DET_X = (r"posud|sudj|omeksiv|mrlj|odstranj|bjelil|\bwc|podov|stakl|kupaon|kuhinj|\bruk|tijel|sampon|perilic ?posudj|tabs ?posud|"
         r"pecivo|puding|kolac|kakao|vanil|secer|\bkav|mlijek|zelatin|sladoled|krem|desert|zacin|curry|cesnj|paprik|osvjez|mirisn ?biser|parfem ?za ?rublj|"
         r"boja ?za|maramic|odstranjivac|kamenac|calgon|antikalc")

GROUPS = [
    # ---------------------------------------------------------------- 1 mlijeko
    dict(id="mlijeko-trajno-28", item="mlijeko", label="Trajno mlijeko 2,8 % m.m., 1 l",
         all=[r"\bmlij", r"traj|\buht|dugotraj|\btm\b", r"\b2\.8"], excl=[MILK_X, r"laktoz|\blf\b"], base="l", amount=[0.95, 1.05], compare="ean"),
    dict(id="mlijeko-trajno-09", item="mlijeko", label="Trajno mlijeko 0,9 % m.m., 1 l",
         all=[r"\bmlij", r"traj|\buht|dugotraj", r"\b0\.9|\b1\.0?\s*%"], excl=[MILK_X, r"laktoz|\blf\b"], base="l", amount=[0.95, 1.05], compare="ean"),
    dict(id="mlijeko-trajno-32", item="mlijeko", label="Trajno mlijeko 3,2–3,5 % m.m., 1 l",
         all=[r"\bmlij", r"traj|\buht|dugotraj", r"\b3\.[2-5]"], excl=[MILK_X, r"laktoz|\blf\b"], base="l", amount=[0.95, 1.05], compare="ean"),
    dict(id="mlijeko-svjeze-28", item="mlijeko", label="Svježe mlijeko 2,8 % m.m., 1 l",
         all=[r"\bmlij", r"svjez|pasteriz|\bsvj\b", r"\b2\.8"], excl=[MILK_X, r"laktoz|traj|\buht"], base="l", amount=[0.95, 1.05], compare="ean"),
    dict(id="mlijeko-svjeze-32", item="mlijeko", label="Svježe mlijeko 3,2–3,8 % m.m., 1 l",
         all=[r"\bmlij", r"svjez|pasteriz|\bsvj\b", r"\b3\.[2-8]"], excl=[MILK_X, r"laktoz|traj|\buht"], base="l", amount=[0.95, 1.05], compare="ean"),
    dict(id="mlijeko-bez-laktoze", item="mlijeko", label="Mlijeko bez laktoze, 1 l",
         all=[r"\bmlij", r"laktoz|\blf\b"], excl=[MILK_X], base="l", amount=[0.95, 1.05], compare="ean"),
    # ---------------------------------------------------------------- 2 jogurt
    dict(id="jogurt-28-1kg", item="jogurt", label="Tekući jogurt 2,8 % m.m., ~1 kg/1 l",
         all=[r"\bjogurt", r"\b2\.8|\b3\.2"], excl=[YOG_X, r"cvrst"], base=["kg", "l"], amount=[0.9, 1.1], compare="ean"),
    dict(id="jogurt-cvrsti", item="jogurt", label="Čvrsti jogurt, 150–200 g",
         all=[r"\bjogurt", r"cvrst"], excl=[YOG_X], base=["kg", "l"], amount=[0.14, 0.21], compare="ean"),
    dict(id="jogurt-grcki", item="jogurt", label="Grčki jogurt (bez okusa)",
         all=[r"\bjogurt", r"grck"], excl=[YOG_X.replace("grck|", "")], base=["kg", "l"], amount=[0.12, 1.1], compare="ean"),
    # ---------------------------------------------------------------- 3 jaja
    dict(id="jaja-m-10", item="jaja", label="Jaja M, 10 kom",
         all=[r"\bjaj[ae]\b", r"\bm\b|vel\w* m\b|\bm vel"], excl=[EGG_X, r"\bl\b|\bxl\b|\bs\b"], base="kom", amount=[10, 10], compare="ean", alt=["jaja-l-10"]),
    dict(id="jaja-l-10", item="jaja", label="Jaja L, 10 kom",
         all=[r"\bjaj[ae]\b", r"\bl\b|vel\w* l\b|\bl vel"], excl=[EGG_X, r"\bxl\b"], base="kom", amount=[10, 10], compare="ean"),
    dict(id="jaja-sva", item="jaja", label="Jaja – bilo koja veličina (cijena po komadu)",
         all=[r"\bjaj[ae]\b"], excl=[EGG_X], base="kom", amount=[6, 30], compare="ean"),
    # ---------------------------------------------------------------- 4 maslac
    dict(id="maslac-250", item="maslac", label="Maslac, 200–250 g",
         all=[r"\bmaslac"], excl=[BUTTER_X], base="kg", amount=[0.2, 0.25], compare="ean"),
    dict(id="maslac-125", item="maslac", label="Maslac, 100–125 g",
         all=[r"\bmaslac"], excl=[BUTTER_X], base="kg", amount=[0.1, 0.125], compare="ean", alt=["maslac-250"]),
    # ---------------------------------------------------------------- 5 sir
    dict(id="sir-gauda-pak", item="sir", label="Gauda, pakirana (komad)",
         all=[r"gaud|gouda"], excl=[CHEESE_X], base="kg", amount=[0.15, 1.2], compare="ean"),
    dict(id="sir-gauda-narezana", item="sir", label="Gauda, narezana",
         all=[r"gaud|gouda", r"narez|listic|ploc|slices"], excl=[r"pecivo|sendvic|pizza|burek|pita"], base="kg", amount=[0.08, 0.6], compare="ean"),
    dict(id="sir-gauda-rinfuza", item="sir", label="Gauda – s pulta / na težinu (kg)",
         all=[r"gaud|gouda"], excl=[CHEESE_X], base="kg", amount=[1.0, 1.0], loose=True, compare="opis"),
    dict(id="sir-trapist", item="sir", label="Trapist, pakirani",
         all=[r"trapist"], excl=[CHEESE_X], base="kg", amount=[0.15, 1.2], compare="ean"),
    dict(id="sir-edamer", item="sir", label="Edamer, pakirani",
         all=[r"\bedam"], excl=[CHEESE_X], base="kg", amount=[0.15, 1.2], compare="ean"),
    dict(id="sir-svjezi", item="sir", label="Svježi kravlji sir, 200 g–1 kg",
         all=[r"svjez\w* sir|sir svjez|\bsvj\w* kravlj"], excl=[CHEESE_X, r"vrhnj|kolac|sladoled|zdenk|gaud|trapist|edam|mozzarel|feta|kozj|ovcj|voc|jagod|vanil|cokol|lagan ?namaz"], base="kg", amount=[0.2, 1.05], compare="ean"),
    # ---------------------------------------------------------------- 6 kruh
    dict(id="kruh-bijeli", item="kruh", label="Bijeli kruh",
         all=[r"\bkruh", r"bijel"], excl=[BREAD_X, r"polubijel"], base="kg", amount=[0.3, 1.1], compare="opis"),
    dict(id="kruh-polubijeli", item="kruh", label="Polubijeli kruh",
         all=[r"\bkruh", r"polubijel"], excl=[BREAD_X], base="kg", amount=[0.3, 1.1], compare="opis"),
    dict(id="kruh-razeni", item="kruh", label="Raženi / crni / integralni kruh",
         all=[r"\bkruh", r"\braz|crn|integral|cjelovit"], excl=[BREAD_X], base="kg", amount=[0.3, 1.1], compare="opis"),
    dict(id="kruh-tost", item="kruh", label="Tost kruh, bijeli",
         all=[r"\btost"], excl=[r"toster|\bsir|sunk|sendvic|integral|razen|\braz|crn|grah|tostir|pecivo|mrvic"], base="kg", amount=[0.4, 0.8], compare="ean"),
    # ---------------------------------------------------------------- 7 brašno
    dict(id="brasno-glatko", item="brasno", label="Pšenično brašno glatko (T-400/T-550), 1 kg",
         all=[r"brasn", r"glatk|t ?550|t ?400|\b550\b|\b400\b"], excl=[FLOUR_X, r"ostr|t ?850|t ?1100"], base="kg", amount=[0.95, 1.05], compare="ean"),
    dict(id="brasno-ostro", item="brasno", label="Pšenično brašno oštro, 1 kg",
         all=[r"brasn", r"ostr"], excl=[FLOUR_X], base="kg", amount=[0.95, 1.05], compare="ean"),
    dict(id="brasno-t850", item="brasno", label="Pšenično brašno T-850, 1 kg",
         all=[r"brasn", r"t ?850|\b850\b"], excl=[FLOUR_X], base="kg", amount=[0.95, 1.05], compare="ean"),
    # ---------------------------------------------------------------- 8 šećer
    dict(id="secer-bijeli", item="secer", label="Bijeli kristal šećer, 1 kg",
         all=[r"\bsecer"], excl=[SUGAR_X], base="kg", amount=[0.95, 1.05], compare="ean"),
    dict(id="secer-smedji", item="secer", label="Smeđi šećer, 0,5–1 kg",
         all=[r"\bsecer", r"smedj|trsk"], excl=[r"vanil|kock|sirup|zamjen|stevi|bombon|keks|kolac"], base="kg", amount=[0.45, 1.05], compare="ean"),
    # ---------------------------------------------------------------- 9 ulje
    dict(id="ulje-suncokret-1l", item="ulje", label="Suncokretovo ulje, 1 l",
         all=[r"suncokr", r"\bulj"], excl=[OIL_X], base="l", amount=[0.95, 1.05], compare="ean", alt=["ulje-suncokret-veliko"]),
    dict(id="ulje-suncokret-veliko", item="ulje", label="Suncokretovo ulje, 2–5 l",
         all=[r"suncokr", r"\bulj"], excl=[OIL_X], base="l", amount=[1.9, 5.1], compare="ean"),
    # ---------------------------------------------------------------- 10 riža
    dict(id="riza-dugo", item="riza", label="Riža dugo zrno, 1 kg",
         all=[r"\briz[ae]?\b", r"dug"], excl=[RICE_X, r"basmati|jasmin|parboil|integral|smedj|crn|divlj|rizot|arborio"], base="kg", amount=[0.95, 1.05], compare="ean"),
    dict(id="riza-okrugla", item="riza", label="Riža okruglo zrno / za rižoto, 0,5–1 kg",
         all=[r"\briz[ae]?\b|arborio|carnaroli"], any=[r"okrugl|arborio|rizot|carnaroli|originario"], excl=[RICE_X, r"gotov|vrecic"], base="kg", amount=[0.45, 1.05], compare="ean"),
    dict(id="riza-basmati", item="riza", label="Basmati riža, 0,5–1 kg",
         all=[r"basmati"], excl=[RICE_X], base="kg", amount=[0.45, 1.05], compare="ean"),
    dict(id="riza-parboiled", item="riza", label="Riža parboiled, 0,5–1 kg",
         all=[r"\briz[ae]?\b", r"parboil"], excl=[RICE_X], base="kg", amount=[0.45, 1.05], compare="ean"),
    # ---------------------------------------------------------------- 11 krumpir
    dict(id="krumpir", item="krumpir", label="Krumpir (rasuti ili pakirani, cijena po kg)",
         all=[r"krumpir"], excl=[POTATO_X], base="kg", amount=[0.9, 25], compare="opis"),
    # ---------------------------------------------------------------- 12 luk
    dict(id="luk-crveni", item="luk", label="Crveni / žuti luk (cijena po kg)",
         all=[r"\bluk\b"], excl=[ONION_X, r"bijel|srebr"], base="kg", amount=[0.4, 10], compare="opis"),
    # ---------------------------------------------------------------- 13 banane
    dict(id="banane", item="banane", label="Banane (cijena po kg)",
         all=[r"\bbanan"], excl=[BANANA_X], base="kg", amount=[0.4, 3], compare="opis"),
    # ---------------------------------------------------------------- 14 jabuke
    dict(id="jabuke", item="jabuke", label="Jabuke (cijena po kg)",
         all=[r"\bjabuk"], excl=[APPLE_X], base="kg", amount=[0.4, 5], compare="opis"),
    # ---------------------------------------------------------------- 15 piletina
    dict(id="pileca-prsa", item="piletina", label="Pileća prsa / file, svježe (cijena po kg)",
         all=[r"\bpil", r"\bprs|\bfile|filet"], excl=[CHICKEN_X], base="kg", amount=[0.25, 3], compare="opis"),
    # ---------------------------------------------------------------- 16 mljeveno meso
    dict(id="mljeveno-mijesano", item="mljeveno", label="Mljeveno meso miješano (svinjetina + junetina)",
         all=[r"mljeven"], any=[r"mjesan|mijesan|svinj\w* ?(i|/|-)? ?junec|junec\w* ?(i|/|-)? ?svinj|svinj\w* ?(i|/|-)? ?govedj"], excl=[MINCE_X], base="kg", amount=[0.25, 3], compare="opis"),
    dict(id="mljeveno-junece", item="mljeveno", label="Mljevena junetina / govedina",
         all=[r"mljeven", r"junet|junec|govedj|goved"], excl=[MINCE_X, r"svinj|mjesan|mijesan|pure|pil"], base="kg", amount=[0.25, 3], compare="opis"),
    dict(id="mljeveno-svinjsko", item="mljeveno", label="Mljevena svinjetina",
         all=[r"mljeven", r"svinj"], excl=[MINCE_X, r"junet|junec|goved|mjesan|mijesan"], base="kg", amount=[0.25, 3], compare="opis"),
    # ---------------------------------------------------------------- 17 tjestenina
    dict(id="spageti-500", item="tjestenina", label="Špageti, 500 g",
         all=[r"spaget|spaghett"], excl=[PASTA_X], base="kg", amount=[0.45, 0.55], compare="ean"),
    dict(id="penne-500", item="tjestenina", label="Penne, 500 g",
         all=[r"\bpenne|\bpene\b"], excl=[PASTA_X], base="kg", amount=[0.45, 0.55], compare="ean"),
    dict(id="fusilli-500", item="tjestenina", label="Fusilli / svrdlići, 500 g",
         all=[r"fusil|svrdl"], excl=[PASTA_X], base="kg", amount=[0.45, 0.55], compare="ean"),
    dict(id="tjestenina-integralna", item="tjestenina", label="Integralna tjestenina, 400–500 g",
         all=[r"integral", r"spaget|penne|fusil|tjesten|makaron|pasta|svrdl"], excl=[r"umak|gotov|juha|salat|kruh|keks|pahulj"], base="kg", amount=[0.4, 0.55], compare="ean"),
    # ---------------------------------------------------------------- 18 kava
    dict(id="kava-mljevena", item="kava", label="Mljevena kava (turska / za filter), 100 g–1 kg",
         all=[r"\bkav[ae]\b|\bcoffee\b|\bcafe\b"], any=[r"mljeven|\bturs|dzezv|filter|espresso mljev"], excl=[COFFEE_X], base="kg", amount=[0.09, 1.05], compare="ean"),
    dict(id="kava-zrno", item="kava", label="Kava u zrnu, 0,5–1 kg",
         all=[r"\bkav[ae]\b|\bcoffee\b|\bcaffe|\bcafe\b", r"zrn|bean"], excl=[r"kapsul|instant|cokol|bombon|keks|liker"], base="kg", amount=[0.45, 1.05], compare="ean"),
    dict(id="kava-instant", item="kava", label="Instant kava (bez dodataka)",
         all=[r"instant|topiv|nescafe|\bgold\b"], any=[r"\bkav|nescafe|coffee"], excl=[r"3 ?u ?1|2 ?u ?1|napitak|cappuc|latte|frape|mocca|cokol|vanil|karamel|kapsul|ledena"], base="kg", amount=[0.04, 0.5], compare="ean"),
    # ---------------------------------------------------------------- 19 toaletni papir
    dict(id="tp-3sl", item="toaletni", label="Toaletni papir 3-slojni (cijena po roli)",
         all=[r"toal\w* ?papir|wc ?papir|toaletni"], any=[r"\b3 ?sl|troslo|3 ?ply"], excl=[TP_X], base="kom", amount=[4, 48], compare="ean"),
    dict(id="tp-2sl", item="toaletni", label="Toaletni papir 2-slojni (cijena po roli)",
         all=[r"toal\w* ?papir|wc ?papir|toaletni"], any=[r"\b2 ?sl|dvoslo|2 ?ply"], excl=[TP_X], base="kom", amount=[4, 48], compare="ean"),
    # ---------------------------------------------------------------- 20 deterdžent
    dict(id="det-tekuci", item="deterdzent", label="Tekući deterdžent / gel za rublje (cijena po pranju)",
         all=[r"deterd|deterg|\bgel\b|tekuc"], any=[r"rublj|\bpran|ariel|persil|faks|bonux|tide|dash|perwoll|rex|savex|biser|lenor|\bwl\b|deterd"],
         excl=[DET_X, r"kapsul|caps|pods|prasak|\bprah"], base="pranje", amount=[10, 200], compare="ean"),
    dict(id="det-prasak", item="deterdzent", label="Deterdžent u prahu (cijena po pranju)",
         all=[r"prasak|\bprah\b|powder"], any=[r"rublj|\bpran|deterd|deterg|ariel|persil|faks|bonux|tide|dash|savex|\bwl\b"],
         excl=[DET_X, r"kapsul|caps|pods|\bgel\b|tekuc"], base="pranje", amount=[10, 200], compare="ean"),
    dict(id="det-kapsule", item="deterdzent", label="Kapsule za rublje (cijena po pranju)",
         all=[r"kapsul|\bcaps|\bpods|discs"], any=[r"rublj|\bpran|deterd|ariel|persil|tide|dash|faks|bonux|savex|perwoll"],
         excl=[DET_X, r"\bkav|nespresso|dolce|kofein"], base="pranje", amount=[8, 120], compare="ean", kom_kao_pranje=True),
]

# Početni popis (redoslijed = prikaz u aplikaciji)
DEFAULT_ITEMS = [
    ("mlijeko", "Mlijeko", "mlijeko-trajno-28", 1),
    ("jogurt", "Jogurt", "jogurt-28-1kg", 1),
    ("jaja", "Jaja", "jaja-m-10", 1),
    ("maslac", "Maslac", "maslac-250", 1),
    ("sir", "Sir", "sir-gauda-pak", 1),
    ("kruh", "Kruh", "kruh-bijeli", 1),
    ("brasno", "Brašno", "brasno-glatko", 1),
    ("secer", "Šećer", "secer-bijeli", 1),
    ("ulje", "Suncokretovo ulje", "ulje-suncokret-1l", 1),
    ("riza", "Riža", "riza-dugo", 1),
    ("krumpir", "Krumpir", "krumpir", 2),
    ("luk", "Luk", "luk-crveni", 1),
    ("banane", "Banane", "banane", 1),
    ("jabuke", "Jabuke", "jabuke", 1),
    ("piletina", "Pileća prsa", "pileca-prsa", 1),
    ("mljeveno", "Mljeveno meso", "mljeveno-mijesano", 0.5),
    ("tjestenina", "Tjestenina", "spageti-500", 1),
    ("kava", "Kava", "kava-mljevena", 1),
    ("toaletni", "Toaletni papir", "tp-3sl", 1),
    ("deterdzent", "Deterdžent za rublje", "det-tekuci", 1),
]
